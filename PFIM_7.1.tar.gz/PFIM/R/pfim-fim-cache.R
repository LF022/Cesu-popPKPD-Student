
.PFIM_FIM_DESIGN_CACHE = new.env( parent = emptyenv() )

#' @keywords internal
.pfimEvaluationFromDesign = function( evaluation, design, evaluatedDesign ) {
  prop( evaluation, "designs" ) <- list( design )
  prop( evaluation, "evaluationDesign" ) <- list( evaluatedDesign )
  prop( evaluation, "fim" ) <- prop( evaluatedDesign, "fim" )
  evaluation
}

#' @keywords internal
.pfimModelCacheId = function( pfimproject ) {
  if ( !isTRUE( getOption( "PFIM.model.cache.signature", TRUE ) ) )
    return( rlang::obj_address( projectOf( pfimproject ) ) )

  params = projectProp( pfimproject, "modelParameters" )
  mu_sig = paste(
    vapply( params, function( p ) {
      d = prop( p, "distribution" )
      paste(
        prop( p, "name" ),
        round( prop( d, "mu" ), 8L ),
        round( prop( d, "omega" ), 8L ),
        sep = ":"
      )
    }, character( 1L ) ),
    collapse = ";"
  )
  lib = projectProp( pfimproject, "modelFromLibrary" )
  lib_key = if ( length( lib ) )
    paste( names( lib ), unlist( lib ), sep = "=", collapse = "," ) else ""
  cov_eq = projectProp( pfimproject, "modelCovariatesEquation" )
  paste(
    projectProp( pfimproject, "fimType" ),
    lib_key,
    mu_sig,
    length( projectProp( pfimproject, "modelCovariates" ) ),
    cov_eq,
    sep = "|"
  )
}

#' @keywords internal
.pfimDesignSignature = function( design ) {
  arms = prop( design, "arms" )
  parts = vapply( arms, function( arm ) {
    adms = prop( arm, "administrations" )
    doses = vapply( adms, function( a ) {
      d = prop( a, "dose" )
      paste( as.numeric( d ), collapse = "," )
    }, character( 1L ) )
    sts = prop( arm, "samplingTimes" )
    samps = vapply( sts, function( s ) {
      paste( as.numeric( prop( s, "samplings" ) ), collapse = "," )
    }, character( 1L ) )
    paste( c( doses, samps ), collapse = ";" )
  }, character( 1L ) )
  paste( parts, collapse = "|" )
}

#' @keywords internal
.pfimFimCacheKey = function( evaluation ) {
  scope = getOption( "PFIM.fim.cache.scope", NULL )
  if ( is.null( scope ) )
    scope = rlang::obj_address( projectOf( evaluation ) )
  design = prop( evaluation, "designs" )[[ 1L ]]
  paste0( scope, "::", .pfimDesignSignature( design ) )
}

#' @keywords internal
.pfimFimCacheBegin = function( optimization ) {
  scope = rlang::obj_address( projectOf( optimization ) )
  options( PFIM.fim.cache.scope = scope )
  .pfimFimCacheClear( scope )
  invisible( scope )
}

#' @keywords internal
.pfimFimCacheClear = function( scope ) {
  prefix = paste0( scope, "::" )
  keys = ls( .PFIM_FIM_DESIGN_CACHE, all.names = TRUE )
  rm( list = keys[ startsWith( keys, prefix ) ], envir = .PFIM_FIM_DESIGN_CACHE )
  invisible( NULL )
}

#' @keywords internal
.pfimFimCacheRegister = function( evaluation ) {
  if ( !isTRUE( getOption( "PFIM.fim.cache", TRUE ) ) )
    return( invisible( NULL ) )
  key = .pfimFimCacheKey( evaluation )
  assign( key, evaluation, envir = .PFIM_FIM_DESIGN_CACHE )
  invisible( key )
}

#' @keywords internal
.pfimRunEvaluationCached = function( evaluation ) {
  if ( !isTRUE( getOption( "PFIM.fim.cache", TRUE ) ) )
    return( run( evaluation ) )

  key = .pfimFimCacheKey( evaluation )
  if ( exists( key, envir = .PFIM_FIM_DESIGN_CACHE, inherits = FALSE ) ) {
    hits = getOption( "PFIM.fim.cache.hits", 0L )
    options( PFIM.fim.cache.hits = hits + 1L )
    return( get( key, envir = .PFIM_FIM_DESIGN_CACHE ) )
  }

  result = run( evaluation )
  assign( key, result, envir = .PFIM_FIM_DESIGN_CACHE )
  result
}

#' @keywords internal
.pfimFimCacheStats = function() {
  list(
    enabled = isTRUE( getOption( "PFIM.fim.cache", TRUE ) ),
    scope   = getOption( "PFIM.fim.cache.scope", NA ),
    size    = length( ls( .PFIM_FIM_DESIGN_CACHE, all.names = TRUE ) ),
    hits    = getOption( "PFIM.fim.cache.hits", 0L )
  )
}
