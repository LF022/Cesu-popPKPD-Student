# Internal helpers shared across PFIM modules.

.PFIM_EVAL_MODEL_CACHE = new.env( parent = emptyenv() )
.PFIM_PARALLEL_STATE    = new.env( parent = emptyenv() )
.PFIM_WORKER_INIT_FLAG = ".pfim_worker_initialized"

#' @keywords internal
.safeCholInv = function( V ) {
  tryCatch(
    chol2inv( chol( V ) ),
    error = function( e ) {
      eps = .Machine$double.eps^0.5 * max( abs( diag( V ) ) )
      chol2inv( chol( V + diag( eps, nrow( V ) ) ) )
    }
  )
}

#' @keywords internal
.safeSolve = function( M ) {
  tryCatch(
    solve( M ),
    error = function( e ) {
      warning(
        "Matrix is singular or ill-conditioned; using Tikhonov-regularized inverse.",
        call. = FALSE
      )
      eps = .Machine$double.eps^0.5 * max( abs( diag( M ) ) )
      solve( M + diag( eps, nrow( M ) ) )
    }
  )
}

#' @keywords internal
.invalidateEvalModelCache = function( pfimproject ) {
  cacheId = .pfimModelCacheId( pfimproject )
  .PFIM_EVAL_MODEL_CACHE[[ cacheId ]] = NULL
  invisible( NULL )
}

#' @keywords internal
.pfimCoresReserve = function() {
  reserve = getOption( "PFIM.cores.reserve", 2L )
  max( 0L, as.integer( reserve ) )
}

#' @keywords internal
.pfimAvailableCores = function() {
  if ( requireNamespace( "parallelly", quietly = TRUE ) ) {
    n = utils::getFromNamespace( "availableCores", "parallelly" )()
    if ( !is.na( n ) && n > 0L )
      return( as.integer( n ) )
  }
  n = parallel::detectCores( logical = TRUE )
  if ( is.na( n ) ) 1L else as.integer( n )
}

#' @keywords internal
.pfimInParallelWorker = function() {
  isTRUE( getOption( "PFIM.inWorker", FALSE ) ) ||
    nzchar( Sys.getenv( "R_PARALLEL_PORT", unset = "" ) )
}

#' @keywords internal
.pfimMaxParallelWorkers = function() {
  reserve = .pfimCoresReserve()
  max( 1L, .pfimAvailableCores() - reserve )
}

#' @keywords internal
.pfimParallelWorkers = function() {
  max_avail = .pfimMaxParallelWorkers()
  w = getOption( "PFIM.workers", NA )
  if ( is.na( w ) )
    return( max_avail )
  max( 1L, min( as.integer( w ), max_avail ) )
}

#' @keywords internal
.pfimParallelPkgsAvailable = function() {
  requireNamespace( "future", quietly = TRUE ) &&
    requireNamespace( "furrr", quietly = TRUE )
}

#' @keywords internal
.pfimUseParallel = function( nTasks = 2L ) {
  isTRUE( getOption( "PFIM.parallel", FALSE ) ) &&
    nTasks > 1L &&
    !.pfimInParallelWorker() &&
    .pfimParallelWorkers() > 1L &&
    .pfimParallelPkgsAvailable()
}

#' @keywords internal
.pfimPackageRoot = function() {
  devPath = getOption( "PFIM.devPath", Sys.getenv( "PFIM_PACKAGE_ROOT", unset = "" ) )
  if ( length( devPath ) == 1L && nzchar( devPath ) && dir.exists( devPath ) )
    return( devPath )
  if ( requireNamespace( "PFIM", quietly = TRUE ) ) {
    desc = system.file( "DESCRIPTION", package = "PFIM" )
    if ( length( desc ) == 1L && nzchar( desc ) && file.exists( desc ) )
      return( dirname( desc ) )
  }
  ""
}

#' @keywords internal
.pfimDynlibPath = function( pkgRoot = "" ) {
  if ( length( pkgRoot ) == 1L && nzchar( pkgRoot ) ) {
    for ( candidate in c(
      file.path( pkgRoot, "src", paste0( "PFIM", .Platform$dynlib.ext ) ),
      file.path( pkgRoot, "libs", "x64", paste0( "PFIM", .Platform$dynlib.ext ) ),
      file.path( pkgRoot, "libs", paste0( "PFIM", .Platform$dynlib.ext ) )
    ) ) {
      if ( file.exists( candidate ) )
        return( candidate )
    }
  }
  lib_dir = system.file( "libs", package = "PFIM" )
  if ( !nzchar( lib_dir ) )
    return( "" )
  arch_dir = file.path( lib_dir, .Platform$r_arch )
  dll = file.path(
    if ( nzchar( .Platform$r_arch ) && dir.exists( arch_dir ) ) arch_dir else lib_dir,
    paste0( "PFIM", .Platform$dynlib.ext )
  )
  if ( file.exists( dll ) )
    return( dll )
  ""
}

#' @keywords internal
.pfimEnsureDynlib = function( pkgRoot = "" ) {
  if ( "PFIM" %in% names( getLoadedDLLs() ) )
    return( invisible( NULL ) )
  dll = .pfimDynlibPath( pkgRoot )
  if ( nzchar( dll ) )
    dyn.load( dll, local = FALSE, now = TRUE )
  invisible( NULL )
}

#' @keywords internal
.pfimParallelWorkerInit = function( pkgRoot = "" ) {
  if ( "PFIM" %in% .packages() ) {
    .pfimEnsureDynlib( pkgRoot )
    return( invisible( NULL ) )
  }

  if ( requireNamespace( "PFIM", quietly = TRUE ) ) {
    suppressWarnings( suppressPackageStartupMessages( attachNamespace( "PFIM" ) ) )
    .pfimEnsureDynlib()
    return( invisible( NULL ) )
  }

  if ( !length( pkgRoot ) || !nzchar( pkgRoot ) )
    pkgRoot = .pfimPackageRoot()

  if ( length( pkgRoot ) == 1L && nzchar( pkgRoot ) &&
       file.exists( file.path( pkgRoot, "DESCRIPTION" ) ) &&
       requireNamespace( "pkgload", quietly = TRUE ) ) {
    suppressWarnings( pkgload::load_all( pkgRoot, quiet = TRUE, compile = FALSE ) )
    if ( !"PFIM" %in% .packages() && isNamespaceLoaded( "PFIM" ) )
      suppressWarnings( suppressPackageStartupMessages( attachNamespace( "PFIM" ) ) )
    .pfimEnsureDynlib( pkgRoot )
    return( invisible( NULL ) )
  }

  stop(
    "Parallel workers cannot load PFIM. Restart R, then run ",
    "devtools::install(quick = TRUE) and configureParallel().",
    call. = FALSE
  )
}

#' @keywords internal
.pfimParallelWorkerInitOnce = function( pkgRoot = "" ) {
  if ( isTRUE( get0( .PFIM_WORKER_INIT_FLAG, envir = .PFIM_PARALLEL_STATE, inherits = FALSE ) ) )
    return( invisible( NULL ) )
  .pfimParallelWorkerInit( pkgRoot )
  assign( .PFIM_WORKER_INIT_FLAG, TRUE, envir = .PFIM_PARALLEL_STATE )
  invisible( NULL )
}

#' @keywords internal
.pfimMissingParallelPkgs = function() {
  c( "future", "furrr" )[
    !vapply( c( "future", "furrr" ), requireNamespace, logical( 1L ), quietly = TRUE )
  ]
}

#' @keywords internal
.pfimParallelPrecheck = function( strict = FALSE ) {
  if ( requireNamespace( "PFIM", quietly = TRUE ) &&
       nzchar( .pfimDynlibPath() ) )
    return( invisible( TRUE ) )

  pkgRoot = .pfimPackageRoot()
  if ( length( pkgRoot ) == 1L && nzchar( pkgRoot ) &&
       file.exists( file.path( pkgRoot, "DESCRIPTION" ) ) &&
       requireNamespace( "pkgload", quietly = TRUE ) &&
       nzchar( .pfimDynlibPath( pkgRoot ) ) )
    return( invisible( TRUE ) )

  msg = paste0(
    "Parallel workers need an installed PFIM package with a compiled DLL. ",
    "Restart R, run devtools::install(quick = TRUE), then configureParallel()."
  )
  if ( strict ) stop( msg, call. = FALSE )
  warning( msg, "\nFalling back to sequential FIM evaluation.", call. = FALSE )
  options( PFIM.parallel = FALSE )
  invisible( FALSE )
}

#' @keywords internal
.pfimParallelWorkerPkgRoot = function() {
  devPath = getOption( "PFIM.devPath", Sys.getenv( "PFIM_PACKAGE_ROOT", unset = "" ) )
  if ( length( devPath ) == 1L && nzchar( devPath ) && dir.exists( devPath ) &&
       nzchar( .pfimDynlibPath( devPath ) ) )
    return( normalizePath( devPath, winslash = "/" ) )
  if ( requireNamespace( "PFIM", quietly = TRUE ) )
    return( "" )
  .pfimPackageRoot()
}

#' @keywords internal
.pfimMuffleRelayedWorkerWarnings = function( expr ) {
  withCallingHandlers(
    expr,
    warning = function( w ) {
      msg = conditionMessage( w )
      if ( grepl( "was built under R version", msg, fixed = TRUE ) )
        invokeRestart( "muffleWarning" )
    }
  )
}

#' @keywords internal
.pfimParallelMap = function( .x, .f, ... ) {
  parallel_requested = isTRUE( getOption( "PFIM.parallel", FALSE ) ) &&
    length( .x ) > 1L &&
    .pfimParallelWorkers() > 1L

  if ( !.pfimUseParallel( length( .x ) ) ) {
    strict = isTRUE( getOption( "PFIM.parallel.strict", FALSE ) )
    if ( parallel_requested && length( .x ) > 1L ) {
      missing_pkgs = .pfimMissingParallelPkgs()
      if ( length( missing_pkgs ) ) {
        msg = sprintf(
          "options(PFIM.parallel = TRUE) requires package(s) %s. Run configureParallel() or install.packages(c('future', 'furrr')).",
          paste( missing_pkgs, collapse = ", " )
        )
        if ( strict ) {
          stop( msg, call. = FALSE )
        }
        if ( !isTRUE( getOption( "PFIM.parallel.fallback.warned", FALSE ) ) ) {
          warning( msg, " Using sequential FIM evaluation.", call. = FALSE )
          options( PFIM.parallel.fallback.warned = TRUE )
        }
        return( purrr::map( .x, .f, ... ) )
      }
      if ( .pfimParallelWorkers() <= 1L ) {
        msg = paste0(
          "options(PFIM.parallel = TRUE) but only one worker is available. ",
          "Use configureParallel(workers = n) or lower PFIM.cores.reserve."
        )
        if ( strict ) stop( msg, call. = FALSE )
        if ( !isTRUE( getOption( "PFIM.parallel.fallback.warned", FALSE ) ) ) {
          warning( msg, " Using sequential FIM evaluation.", call. = FALSE )
          options( PFIM.parallel.fallback.warned = TRUE )
        }
        return( purrr::map( .x, .f, ... ) )
      }
    }
    return( purrr::map( .x, .f, ... ) )
  }

  precheck = .pfimParallelPrecheck( strict = isTRUE( getOption( "PFIM.parallel.strict", FALSE ) ) )
  if ( isFALSE( precheck ) )
    return( purrr::map( .x, .f, ... ) )
  if ( isFALSE( .pfimEnsureParallelReady() ) )
    return( purrr::map( .x, .f, ... ) )
  old_plan = future::plan()
  on.exit( future::plan( old_plan ), add = TRUE )
  workers = .pfimParallelWorkers()
  future::plan( future::multisession, workers = workers )

  pfim_ns     = asNamespace( "PFIM" )
  worker_init = get( ".pfimParallelWorkerInit", envir = pfim_ns, inherits = FALSE )
  init_flag   = .PFIM_WORKER_INIT_FLAG
  pkg_root    = .pfimParallelWorkerPkgRoot()

  .pfimMuffleRelayedWorkerWarnings(
    furrr::future_map(
      .x,
      function( item, ... ) {
        options( PFIM.inWorker = TRUE )
        worker_state = get( ".PFIM_PARALLEL_STATE", envir = asNamespace( "PFIM" ) )
        if ( !isTRUE( get0( init_flag, envir = worker_state, inherits = FALSE ) ) ) {
          suppressWarnings( worker_init( pkg_root ) )
          assign( init_flag, TRUE, envir = worker_state )
        }
        .f( item, ... )
      },
      ...,
      .options = furrr::furrr_options( globals = FALSE, seed = FALSE )
    )
  )
}

#' @keywords internal
.pfimRunEvaluations = function( evaluations ) {
  if ( !length( evaluations ) )
    return( evaluations )
  indices = seq_along( evaluations )
  .pfimParallelMap( indices, function( i ) .pfimRunEvaluationCached( evaluations[[ i ]] ) )
}

#' @keywords internal
.evaluateFimConstraintsCell = function(
    fimIndex,
    iterDose,
    iterComb,
    totalIterations,
    show_progress,
    parallel_progress,
    evaluation,
    design,
    arms,
    dosesForDesign,
    samplingsForFIMs,
    designName,
    combinationGrid,
    baseModel = NULL,
    baseFim   = NULL ) {

  armsWithDoses = purrr::map( arms, function( arm ) {
    armName         = prop( arm, "name" )
    administrations = prop( arm, "administrations" )
    administrations = purrr::map( administrations, function( adm ) {
      prop( adm, "dose" ) <- dosesForDesign[[ armName ]][[ prop( adm, "outcome" ) ]][ iterDose ]
      adm
    } )
    prop( arm, "administrations" ) <- administrations
    arm
  } )

  armsUpdated = purrr::map( armsWithDoses, function( arm ) {
    armName       = prop( arm, "name" )
    idx           = combinationGrid[ iterComb, armName ]
    samplingEntry = purrr::pluck( samplingsForFIMs, designName, armName, idx )
    prop( arm, "samplingTimes" ) <- samplingEntry
    list(
      arm = arm,
      samplingsForFW = unlist(
        purrr::map( samplingEntry, ~ prop( .x, "samplings" ) ),
        use.names = FALSE
      )
    )
  } )

  armResult  = armsUpdated[[ 1L ]]
  tempDesign = design
  prop( tempDesign, "arms" ) <- list( armResult$arm )

  if ( !is.null( baseModel ) && !is.null( baseFim ) ) {
    evaluatedDesign = evaluateDesign( tempDesign, baseModel, baseFim )
    fisherMatrix    = prop( prop( evaluatedDesign, "fim" ), "fisherMatrix" )
    evalResult      = .pfimEvaluationFromDesign( evaluation, tempDesign, evaluatedDesign )
  } else {
    tempEval   = evaluation
    prop( tempEval, "designs" ) <- list( tempDesign )
    evalResult = .pfimRunEvaluationCached( tempEval )
    fim        = getFim( evalResult )
    fisherMatrix = fim$fisherMatrix
  }

  dimFim       = nrow( fisherMatrix )
  dimVec       = dimFim * ( dimFim + 1L ) / 2L

  fisherMatrixForAlgoFW = matrix(
    fisherMatrix[ rev( lower.tri( t( fisherMatrix ), diag = TRUE ) ) ],
    ncol  = dimVec,
    byrow = TRUE
  )

  if ( show_progress ) {
    message( sprintf( "FIM evaluation: %d / %d", fimIndex, totalIterations ) )
    if ( parallel_progress && interactive() )
      utils::flush.console()
  }

  list(
    armResult             = armResult,
    samplingsForFW        = armResult$samplingsForFW,
    fisherMatrixForAlgoFW = fisherMatrixForAlgoFW,
    fisherMatrix          = fisherMatrix,
    dimFim                = dimFim,
    cachedEvaluation      = evalResult
  )
}



#' @keywords internal

.as_df_rows = function( lst ) {

  if ( length( lst ) == 0L )

    return( as.data.frame( list() ) )

  map( lst, ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |> list_rbind()

}



#' @keywords internal

.constraintsArmsTable = function( armsConstraints ) {

  map( armsConstraints, .as_df_rows ) |> list_rbind()

}



#' @keywords internal

.armConstraintsContinuous = function( arm ) {

  armName = prop( arm, "name" )

  armSize = prop( arm, "size" )

  map( prop( arm, "samplingTimesConstraints" ), function( samplingConstraint ) {

    outcome = prop( samplingConstraint, "outcome" )

    initialSamplings = paste0(

      "(", paste( prop( samplingConstraint, "initialSamplings" ), collapse = ", " ), ")"

    )

    samplingsWindows = paste(

      map_chr(

        prop( samplingConstraint, "samplingsWindows" ),

        ~ paste0( "(", paste( .x, collapse = "," ), ")" )

      ),

      collapse = ", "

    )

    numberOfTimesByWindows = paste0(

      "(", paste( prop( samplingConstraint, "numberOfTimesByWindows" ), collapse = ", " ), ")"

    )

    minSampling = paste0(

      "(", paste( prop( samplingConstraint, "minSampling" ), collapse = ", " ), ")"

    )

    list(

      "Arms name"                  = armName,

      "Number of subjects"         = armSize,

      "Outcome"                    = outcome,

      "Initial samplings"          = initialSamplings,

      "Samplings windows"          = samplingsWindows,

      "Number of times by windows" = numberOfTimesByWindows,

      "Min sampling"               = minSampling

    )

  } )

}

