#' @title ModelODE
#' @description Base class for models integrated with \code{deSolve}.
#' @inheritParams Model
#' @include Model.R
#' @export

ModelODE = new_class( "ModelODE", package = "PFIM", parent = Model )

# ==============================================================================
# Package-internal helpers — not exported.
# All ODE model subclasses share these to avoid duplication.
# ==============================================================================

# Extract named numeric vector of parameter values from ModelParameter objects.
# Uses distribution$mu for estimated parameters; fixed constants use the value slot
# (S7 still attaches a default Distribution with mu = 0 for value-only parameters).
.scalar_finite = function( x ) {
  length( x ) == 1L && !is.na( x ) && is.finite( x )
}

.extractMu = function( parameters ) {
  set_names(
    map_dbl( parameters, function( parameter ) {
      distribution = prop( parameter, "distribution" )
      value        = prop( parameter, "value" )

      if ( !is.null( distribution ) ) {
        omega = prop( distribution, "omega" )
        mu    = prop( distribution, "mu" )
        if ( .scalar_finite( omega ) && omega != 0 )
          return( mu )
        if ( .scalar_finite( mu ) && mu != 0 && !.scalar_finite( value ) )
          return( mu )
      }
      if ( .scalar_finite( value ) )
        return( value )
      if ( !is.null( distribution ) && .scalar_finite( prop( distribution, "mu" ) ) )
        return( prop( distribution, "mu" ) )
      NA_real_
    }),
    map_chr( parameters, ~ prop( .x, "name" ) )
  )
}

# Build a sorted, deduplicated sampling grid with 0 prepended.
.buildSamplings = function( samplingTimes ) {
  s = map( samplingTimes, ~ prop( .x, "samplings" ) ) |> unlist() |> sort() |> unique()
  c( 0.0, s[ s != 0 ] )
}

# Extract the unique administered outcome names from an Evaluation object.
.getOutcomesFromEvaluation = function( evaluation ) {
  prop( evaluation, "designs" ) |>
    map( \(d) prop( d, "arms" ) ) |>
    list_flatten() |>
    map( \(arm) prop( arm, "administrations" ) ) |>
    list_flatten() |>
    map_chr( \(adm) prop( adm, "outcome" ) ) |>
    unique()
}

# Library equations are keyed by output names (e.g. "RespPK") while dosing may
# target compartment names (e.g. "C1") via outputs = list(RespPK = "C1").
.administeredLibraryOutcomeNames = function( evaluation ) {
  adminOutcomes = .getOutcomesFromEvaluation( evaluation )
  outputs       = prop( evaluation, "outputs" )
  if ( length( outputs ) == 0L ) return( adminOutcomes )
  outputValues = unlist( outputs, use.names = TRUE )
  outputNames  = names( outputValues )
  if ( is.null( outputNames ) ) outputNames = as.character( outputValues )
  kept = outputValues %in% adminOutcomes
  if ( any( kept ) ) outputNames[ kept ] else adminOutcomes
}

# Time variable for a library equation name, e.g. RespPK -> t_C1 when outputs map C1.
.libraryEquationTimeName = function( evaluation, libraryOutcomeName ) {
  outputs = prop( evaluation, "outputs" )
  admin   = outputs[[ libraryOutcomeName ]]
  paste0( "t_", if ( !is.null( admin ) && nzchar( admin ) ) admin else libraryOutcomeName )
}

.libraryEquationTimeNames = function( evaluation, libraryOutcomeNames ) {
  map_chr( libraryOutcomeNames, ~ .libraryEquationTimeName( evaluation, .x ) )
}

# Compile a named list of equation strings into a single R function.
# equations        : named list/vector of character strings, e.g. list("Deriv_C1" = "-k*C1")
# functionArguments: character vector of argument names for the compiled function
.buildODEWrapper = function( equations, functionArguments ) {
  body = paste(
    paste( map_chr( names( equations ),
                    ~ sprintf( "%s = %s", .x, equations[[.x]] ) ),
           collapse = "\n" ),
    sprintf( "return(list(c(%s)))", paste( names( equations ), collapse = ", " ) ),
    sep = "\n"
  )
  eval( parse( text = sprintf( "function(%s) { %s }",
                               paste( functionArguments, collapse = ", " ), body ) ) )
}

# Shared evaluateInitialConditions implementation used by ModelODE and ModelODEInfusion.
# mu values are injected into the local environment so that string expressions
# (e.g. "dose_C1/Vd") can reference parameter names directly.
.evalInitialConditionsImpl = function( model, arm ) {
  mu = .extractMu( prop( model, "modelParameters" ) )
  list2env( as.list( mu ), envir = environment() )
  imap( prop( arm, "initialConditions" ), function( ic, compartment ) {
    if ( is.numeric( ic ) )
      return( ic )
    eval( parse( text = ic ) )
  }) |> unlist()
}

# ==============================================================================
#' evaluateInitialConditions: evaluate the initial conditions.
#' @name evaluateInitialConditions
#' @param model A \code{ModelODE} object.
#' @param arm An \code{Arm} object.
#' @return A named numeric vector of evaluated initial conditions.
#' @export
# ==============================================================================

method( evaluateInitialConditions, ModelODE ) = function( model, arm ) {
  .evalInitialConditionsImpl( model, arm )
}
