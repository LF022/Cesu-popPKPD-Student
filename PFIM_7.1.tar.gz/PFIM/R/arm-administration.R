# Arm administration and tabular export helpers.
# @include Arm.R

# ==============================================================================
#' getArmAdministration: get the administration parameters of an arm.
#' @name armAdministration
#' @param arm An \code{Arm} object.
#' @return A list with the administration parameters of an arm.
#' @export
# ==============================================================================

method( armAdministration, Arm ) = function( arm ) {

  armName = prop( arm, "name")
  armSize = round( prop( arm, "size" ), 2 )
  adminList = prop( arm, "administrations" )

  admin = map( adminList, function( adm ) {
    outcome = prop( adm, "outcome" )
    dose = as.character( prop( adm, "dose" ) )
    timeDose = as.character( prop( adm, "timeDose" ) )
    Tinf = prop( adm, "Tinf" )
    Tinf_str = if ( length( Tinf ) > 0 ) as.character( Tinf ) else "."

    list(
      "Design name"        = "Design optimized",
      "Arms name"          = armName,
      "Number of subjects" = as.character( armSize ),
      "Outcome"            = prop( adm, "outcome" ),
      "Dose"               = as.character( prop( adm, "dose" ) ),
      "Time of dose"       = if ( length( prop( adm, "timeDose" ) ) > 0 ) as.character( prop( adm, "timeDose" ) ) else ".",
      "tau"                = as.character( prop( adm, "tau" ) ),
      "Tinf"               = if ( length( prop( adm, "Tinf" ) ) > 0 ) as.character( prop( adm, "Tinf" ) ) else "."
    )
  })
  return( admin )
}

# ==============================================================================
#' getArmData: extract arm data for The Report
#' @name getArmData
#' @param arm An \code{Arm} object.
#' @return A list with the name, Number of subjects, Outcome, Dose and Sampling times of the arm.
#' @export
# ==============================================================================

method( getArmData, Arm ) = function( arm ) {
  armName = prop(arm, "name")
  armSize = round(prop(arm, "size"), 2)

  administrations = prop(arm, "administrations")
  doseList = map(administrations, function(adm) {
    list(
      outcome = prop(adm, "outcome"),
      dose = prop(adm, "dose") )
  })

  doseMap = flatten(doseList)
  doseDict = setNames(
    map(doseList, ~ paste(.x$dose, collapse = ", ")),
    map_chr(doseList, ~ .x$outcome) )

  samplingList = prop(arm, "samplingTimes")
  samplingOutcomes = map_chr(samplingList, ~ prop(.x, "outcome"))
  samplingTimes = map(samplingList, ~ prop(.x, "samplings"))

  armData = map2(samplingOutcomes, samplingTimes, function(outc, samps) {
    doseVal = if (outc %in% names(doseDict)) doseDict[[outc]] else "."
    list( "Arms name" = armName,
          "Number of subjects" = as.character(armSize),
          "Outcome" = outc,
          "Dose" = doseVal,
          "Sampling times" = paste0("(", paste( round(samps,2), collapse = ", "), ")") )
  })
  return( armData )
}

# ==============================================================================
#' getSamplingData: extract sampling times and max sampling time used for plot.
#' @name getSamplingData
#' @param arm An \code{Arm} object.
#' @return A list with the \code{samplingTimes} object, the vector samplings and the double samplingMax.
#' @export
# ==============================================================================

method( getSamplingData, Arm ) = function( arm ) {
  samplingTimes = prop( arm, "samplingTimes" )
  samplings = map(samplingTimes, ~ prop( .x, "samplings" ) ) |>
    set_names(map_chr(samplingTimes, ~ prop(.x ,"outcome" ) ) )
  samplingMax = samplings |> flatten_dbl() |> max()
  list(samplingTimes = samplingTimes, samplings = samplings, samplingMax = samplingMax)
}

# ==============================================================================
#' updateSamplingTimes: update sampling times for plotting used for plot
#' @name updateSamplingTimes
#' @param arm An \code{Arm} object.
#' @param samplingData The list giving as output in the method getSamplingData.
#' @return The updated sampling times.
#' @export
# ==============================================================================

method( updateSamplingTimes, Arm ) = function( arm, samplingData ) {
  prop( arm, "samplingTimes" ) <- map(samplingData$samplingTimes, function(samplingsPlot) {
    prop( samplingsPlot, "samplings" ) <- sort(unique(c(samplingData$samplings |> flatten_dbl(), seq(0.0, samplingData$samplingMax, 0.1))))
    return(samplingsPlot)
  })
  arm
}
