# Constraint-grid FIM enumeration for design optimization.
# @include Optimization.R
# @include pfim-fim-cache.R
# @include pfim-utils.R

# ==============================================================================
#' generateFimsFromConstraints: enumerate and evaluate all FIMs from constraints
#' @name generateFimsFromConstraints
#' @param optimization An \code{Optimization} object.
#' @return A list with listArms, dimFim, listFimsAlgoFW, listFimsAlgoMult,
#'   samplingsForFedorovWynnAlgo.
#'
#' @section FIM design cache:
#' When \code{options(PFIM.fim.cache = TRUE)} (default), evaluated designs are
#' cached during constraint enumeration. Final initial/optimal design evaluations
#' @section Parallel evaluation:
#' When \code{options(PFIM.parallel = TRUE)}, constraint-grid FIM evaluations run
#' in parallel via \pkg{future} and \pkg{furrr} (Suggests). Control worker count
#' with \code{options(PFIM.workers = n)} (capped by \code{detectCores() - PFIM.cores.reserve},
#' reserve default 2).
#' During development, set \code{options(PFIM.devPath = "/path/to/PFIM")} so
#' workers load the same source tree with \pkg{pkgload} when \code{PFIM.devPath} is set.
#' @export
# ==============================================================================

method( generateFimsFromConstraints, Optimization ) = function( optimization ) {

  show_progress = isTRUE( projectProp( optimization, "optimizerParameters" )$showProcess ) ||
    isTRUE( getOption( "PFIM.verbose", FALSE ) )

  .pfimFimCacheBegin( optimization )
  options( PFIM.fim.cache.hits = 0L )

  old_batch = getOption( "PFIM.eval.batch", NULL )
  on.exit( options( PFIM.eval.batch = old_batch ), add = TRUE )
  options( PFIM.eval.batch = TRUE )

  evaluation = .evaluationFromProject( optimization )
  baseModel  = rebuildEvalModel( evaluation, finiteDifference = TRUE )
  baseFim    = defineFim( evaluation )
  designs     = projectProp( optimization, "designs" )
  designNames = map_chr( designs, ~ prop( .x, "name" ) )

  dosesForFIMs    = map( designs, ~ generateDosesCombination( .x ) ) |>
    set_names( designNames )
  samplingsForFIMs = map( designs, ~ generateSamplingTimesCombination( .x ) ) |>
    set_names( designNames )

  allResults = imap( set_names( designs, designNames ), function( design, designName ) {

    arms           = prop( design, "arms" )
    if ( length( arms ) > 1L )
      stop(
        "generateFimsFromConstraints: single-arm designs only; design '",
        designName, "' has ", length( arms ), " arm(s).", call. = FALSE
      )
    dosesForDesign = dosesForFIMs[[ designName ]]
    numberOfDoses  = dosesForDesign$numberOfDoses

    combinationGrid = expand.grid(
      map( samplingsForFIMs[[ designName ]], seq_along )
    )
    nCombinations      = nrow( combinationGrid )
    totalIterations    = numberOfDoses * nCombinations
    use_parallel       = .pfimUseParallel( totalIterations )
    parallel_progress  = show_progress && use_parallel

    if ( parallel_progress )
      message( sprintf(
        "FIM evaluation: running %d tasks on %d workers",
        totalIterations, .pfimParallelWorkers()
      ) )

    eval_cell   = get(
      ".evaluateFimConstraintsCell",
      envir = asNamespace( "PFIM" ),
      inherits = FALSE
    )
    taskIndices = seq_len( totalIterations )
    fim_eval_started = proc.time()
    perDesignResults = .pfimParallelMap( taskIndices, function( fimIndex ) {
      iterDose = ( fimIndex - 1L ) %/% nCombinations + 1L
      iterComb = ( fimIndex - 1L ) %% nCombinations + 1L
      eval_cell(
        fimIndex            = fimIndex,
        iterDose            = iterDose,
        iterComb            = iterComb,
        totalIterations     = totalIterations,
        show_progress       = show_progress,
        parallel_progress   = parallel_progress,
        evaluation          = evaluation,
        design              = design,
        arms                = arms,
        dosesForDesign      = dosesForDesign,
        samplingsForFIMs    = samplingsForFIMs,
        designName          = designName,
        combinationGrid     = combinationGrid,
        baseModel           = baseModel,
        baseFim             = baseFim
      )
    } )

    if ( parallel_progress ) {
      elapsed = ( proc.time() - fim_eval_started )[["elapsed"]]
      message( sprintf(
        "FIM evaluation: %d / %d done (%.1f s)",
        totalIterations, totalIterations, elapsed
      ) )
    }

    for ( cell in perDesignResults )
      if ( !is.null( cell$cachedEvaluation ) )
        .pfimFimCacheRegister( cell$cachedEvaluation )

    perDesignResults
  })

  list(
    listArms                    = map( allResults, ~ map( .x, "armResult"             ) ),
    dimFim                      = allResults[[ 1L ]][[ 1L ]]$dimFim,
    listFimsAlgoFW              = map( allResults, ~ map( .x, "fisherMatrixForAlgoFW" ) ),
    listFimsAlgoMult            = map( allResults, ~ map( .x, "fisherMatrix"          ) ),
    samplingsForFedorovWynnAlgo = map( allResults, ~ map( .x, "samplingsForFW"        ) )
  )
}
