# ==============================================================================
#' Report: generate the HTML evaluation report.
#' @name Report
#' @param pfimproject A \code{PFIMProject} object (Evaluation after run()).
#' @param outputPath  Directory for the rendered HTML file.
#' @param outputFile  File name for the rendered HTML file.
#' @param plotOptions A list of plot options.
#' @return The HTML report of the design evaluation.
#' @export
# ==============================================================================

method( Report, Evaluation ) = function( pfimproject, outputPath, outputFile, plotOptions )
{
  projectName       = prop( pfimproject, "name"    )
  evaluationOutputs = prop( pfimproject, "outputs" )

  # Model equations (same pipeline as run(): library models must be resolved first)
  model          = rebuildEvalModel( pfimproject, finiteDifference = FALSE )
  modelEquations = prop( model, "modelEquations" )

  # â”€â”€ Model error table â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  modelErrorData = prop( pfimproject, "modelError" ) |>
    map( getModelErrorData ) |>
    map( ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |>
    list_rbind()
  colnames( modelErrorData ) = c( "Output", "Type", "$\\sigma_{slope}$", "$\\sigma_{inter}$" )
  modelErrorTable = kbl( modelErrorData, align = c( "c","c","c","c" ) ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE, position = "center", font_size = 13 )

  # â”€â”€ Model parameters table (with IOV column) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  modelParametersTable = .buildModelParametersKable( prop( pfimproject, "modelParameters" ) )

  # â”€â”€ Covariates: structure table + CovariateTest tables â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  modelCovariates = prop( pfimproject, "modelCovariates" )
  hasCov          = length( modelCovariates ) > 0L

  covariatesTable     = .buildCovariatesKable( modelCovariates )          # NULL if no covariates
  covariateTestTables = if ( hasCov ) .buildCovariateTestSection( pfimproject ) else NULL

  # â”€â”€ Arm tables â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  designs      = prop( pfimproject, "designs" )
  designsNames = map_chr( designs, "name" )
  arms         = map( designs, ~ prop( .x, "arms" ) )
  armsData     = list_flatten( map( pluck( arms, 1 ), getArmData ) )

  # Administration table
  administrationData = list_flatten( map( pluck( arms, 1 ), armAdministration ) ) |>
    map( ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |>
    list_rbind()
  colnames( administrationData ) = c( "Design name", "Arms name", "Number of subjects",
                                      "Outcome", "Dose", "Time dose", "$\\tau$", "$T_{inf}$" )
  administrationTable = kbl( administrationData, align = c( "l","l","l","c","c","c","c" ) ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE, position = "center", font_size = 13 )

  # Initial design table
  initialDesignData = armsData |>
    map( ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |>
    list_rbind()
  colnames( initialDesignData ) = c( "Arms name", "Number of subjects", "Outcome", "Dose", "Sampling times" )
  initialDesignTable = kbl( initialDesignData, align = c( "l","c","c","c" ) ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE, position = "center", font_size = 13 )

  # â”€â”€ Fisher matrix, SE/RSE tables â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  fim                   = prop( pfimproject, "fim" )
  fim                   = setEvaluationFim( fim, pfimproject )
  fimInitialDesignTable = tablesForReport( fim, pfimproject )

  # â”€â”€ Plots â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  plotsEvaluation = plotEvaluation( pfimproject, plotOptions )
  plotsSI         = plotSensitivityIndices( pfimproject, plotOptions )
  plotSEBars      = plotSE( pfimproject )
  plotRSEBars     = plotRSE( pfimproject )

  # Assemble and render
  reportTables = list(
    evaluationOutputs      = evaluationOutputs,
    modelEquations         = modelEquations,
    modelErrorTable        = modelErrorTable,
    modelParametersTable   = modelParametersTable,
    covariatesTable        = covariatesTable,
    covariateTestTables    = covariateTestTables,
    administrationTable    = administrationTable,
    initialDesignTable     = initialDesignTable,
    fimInitialDesignTable  = fimInitialDesignTable,
    plotsEvaluation        = plotsEvaluation,
    plotSensitivityIndices = plotsSI,
    plotSE                 = plotSEBars,
    plotRSE                = plotRSEBars,
    fim                    = fim,
    pfimproject            = pfimproject,
    projectName            = projectName
  )

  generateReportEvaluation( fim, reportTables,
                            outputFile = outputFile,
                            outputPath = outputPath )
}
