# ==============================================================================
#' plotEvaluation: Plot model responses for design evaluation
#'
#' @description
#' Generates graphical representations of the model responses based on the
#' design and parameters defined in the PFIM project.
#'
#' @name plotEvaluation
#' @param pfimproject An object of class \code{PFIMProject} containing the design.
#' @param plotOptions A \code{list} specifying graphical parameters (e.g., \code{xlim}, \code{ylim}, \code{main}, \code{col}).
#' @return A series of plots representing the expected model responses and sampling schedules.
#'
#' @examples
#' \dontrun{
#' # 1. Define custom plot options, e.g. form the Vignette 01:
#' myPlotOptions = list( unitTime = c( "hour" ), unitOutcomes= c( "mcg/mL" , "DI%" ) )
#'
#' # 2. Generate the plots for the project
#' plotEvaluation(myPFIMproject, plotOptions = myPlotOptions)
#' }
#' @export
# ==============================================================================

method( plotEvaluation, Evaluation ) = function( pfimproject, plotOptions )
{
  designs = prop( pfimproject, "designs" )
  model = rebuildEvalModel( pfimproject, finiteDifference = TRUE )
  fim = defineFim( pfimproject )
  design = pluck( designs, 1 )
  designName = prop( design, "name" )
  arms = prop( design, "arms" )
  # generate and print all plots
  allPlots = map( arms, ~ processArmEvaluationResults( .x, model, fim, designName, plotOptions ) )
  allPlots = setNames( list( allPlots |> map( ~ .x[[designName]] ) |> list_flatten() ), designName )
  return( allPlots )
}

# ==============================================================================
#' plotSensitivityIndices: Plot gradients of the model responses
#'
#' @description
#' Generates plots for the sensitivity indices (partial derivatives) of the model
#' responses with respect to the population parameters. This is essential for
#' identifying the optimal sampling times where the model is most sensitive to
#' parameter changes.
#'
#' @name plotSensitivityIndices
#' @param pfimproject An object of class \code{PFIMProject} containing the design and model specifications.
#' @param plotOptions A \code{list} specifying graphical parameters for the sensitivity plots.
#' @return A series of plots showing the sensitivity of model responses over time for each parameter.
#'
#' @examples
#' \dontrun{
#' # 1. Define custom plot options, e.g. form the Vignette 01:
#' myPlotOptions = list( unitTime = c( "hour" ), unitOutcomes= c( "mcg/mL" , "DI%" ) )
#'
#' # 2. Generate sensitivity index plots for the current project
#' plotSensitivityIndices(myPFIMproject, plotOptions = myPlotOptions)
#' }
#' @export
# ==============================================================================

method( plotSensitivityIndices, Evaluation ) = function( pfimproject, plotOptions )
{
  designs = prop( pfimproject, "designs" )
  model = rebuildEvalModel( pfimproject, finiteDifference = TRUE )
  fim = defineFim( pfimproject )
  design = pluck( designs, 1 )
  designName = prop( design, "name" )
  arms = prop( design, "arms" )

  # generate and print all plots
  allPlots = map( arms, ~ processArmEvaluationSI( .x, model, fim, designName, plotOptions ) )
  allPlots = setNames( list( allPlots |> map( ~ .x[[designName]] ) |> list_flatten() ), designName )
  return( allPlots )
}

# ==============================================================================
#' plotSE: Bar plot of Standard Errors (SE)
#'
#' @description
#' Generates a bar plot showing the Standard Errors (SE) for the fixed effects
#' and variance components of the model. This visualization helps assess the
#' expected precision of the parameter estimates for the current design.
#'
#' @name plotSE
#' @param pfimproject An object of class \code{PFIMProject} containing the evaluation results.
#' @return A bar plot displaying the calculated SE for each model parameter.
#'
#' @examples
#' \dontrun{
#' # Assuming 'myPFIMproject' has been evaluated using run()
#'
#' # Generate the bar plot of Standard Errors
#' plotSE(myPFIMproject)
#' }
#' @export
# ==============================================================================

# plot SE  from evaluation
method( plotSE, Evaluation ) = function( pfimproject )
{
  # set the FIM and plot SE
  fim = prop( pfimproject, "fim" )
  plotSE = plotSEFIM( fim, pfimproject )
  return( plotSE )
}

# ==============================================================================
#' plotRSE: Bar plot of Relative Standard Errors (RSE)
#'
#' @description
#' Generates a bar plot showing the Relative Standard Errors (RSE, expressed as a
#' percentage) for the model parameters. This visualization is essential for
#' checking if the design meets the target precision criteria (e.g., RSE < 20%).
#'
#' @name plotRSE
#' @param pfimproject An object of class \code{PFIMProject} containing the evaluation results.
#' @return A bar plot displaying the RSE (%) for each model parameter.
#'
#' @examples
#' \dontrun{
#' # Assuming 'myPFIMproject' has been evaluated using the run() function
#'
#' # Generate the bar plot of Relative Standard Errors
#' plotRSE(myPFIMproject)
#' }
#' @export
# ==============================================================================

method( plotRSE, Evaluation ) = function( pfimproject )
{
  # set the FIM and plot RSE
  fim = prop( pfimproject, "fim" )
  plotRSE = plotRSEFIM( fim, pfimproject )
  return( plotRSE )
}
