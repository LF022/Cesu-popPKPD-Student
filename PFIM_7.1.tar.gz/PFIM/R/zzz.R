# S7 classes must be re-registered with S4 on load. Install-time S4_register()
# runs in a separate R process and does not persist when the package is loaded.
.registerS7WithS4 = function(pkgname) {
  ns = asNamespace(pkgname)
  for (nm in c(
    "BayesianFim", "CovariateTest", "Evaluation", "FedorovWynnAlgorithm",
    "IndividualFim", "MultiplicativeAlgorithm", "Optimization",
    "PGBOAlgorithm", "PopulationFim", "PSOAlgorithm", "SimplexAlgorithm"
  )) {
    if (exists(nm, envir = ns, inherits = FALSE)) {
      S4_register(get(nm, envir = ns))
    }
  }
}

.onLoad = function(libname, pkgname) {
  if ( getRversion() < "4.4.0" ) {
    `%||%` = function(x, y) if ( is.null( x ) ) y else x
    assign( "%||%", `%||%`, envir = asNamespace( pkgname ) )
  }
  ns = asNamespace( pkgname )
  pkg_root = normalizePath( file.path( getNamespaceInfo( ns, "path" ), ".." ), winslash = "/" )
  if ( file.exists( file.path( pkg_root, "DESCRIPTION" ) ) &&
       is.null( getOption( "PFIM.devPath" ) ) )
    options( PFIM.devPath = pkg_root )
  if ( exists( ".pfimParallelAutoSetup", envir = ns, inherits = FALSE ) )
    get( ".pfimParallelAutoSetup", envir = ns )()
  .registerS7WithS4( pkgname )
  S7::methods_register()
}

utils::globalVariables(c("."))

