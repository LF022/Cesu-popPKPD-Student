# Gradient / ODE performance helpers (enabled by default; user scripts unchanged).
#
# Options (all optional):
#   PFIM.perf.adminCache     — reuse ODE administration setup across FD perturbations (default TRUE)
#   PFIM.perf.fdCache        — reuse finite-difference scheme when mu is unchanged (default TRUE)
#   PFIM.perf.odeTimesCache  — reuse deSolve time grid within one administration (default TRUE)
#   PFIM.parallel.gradients  — parallel FD columns via future/furrr (default FALSE, opt-in)
NULL

.PFIM_FD_SCHEME_CACHE   = new.env( parent = emptyenv() )
.PFIM_GRAD_ADMIN_CACHE  = new.env( parent = emptyenv() )
.PFIM_ODE_SIM_GRID      = new.env( parent = emptyenv() )

.pfimPerfOption = function( name, default = FALSE ) {
  isTRUE( getOption( name, default ) )
}

.pfimMuSignature = function( parameters ) {
  paste(
    map_chr( parameters, ~ prop( .x, "name" ) ),
    format(
      map_dbl( parameters, ~ prop( prop( .x, "distribution" ), "mu" ) ),
      digits = 12, scientific = TRUE
    ),
    sep = "=",
    collapse = "|"
  )
}

.pfimArmAdminSignature = function( arm ) {
  adms = prop( arm, "administrations" )
  sts  = prop( arm, "samplingTimes" )
  ic   = prop( arm, "initialConditions" )

  dose_sig = vapply( adms, function( adm ) {
    dosing = .alignAdministrationDosing( adm )
    paste(
      prop( adm, "outcome" ),
      paste( dosing$timeDose, collapse = "," ),
      paste( dosing$dose, collapse = "," ),
      prop( adm, "tau" ),
      sep = ":"
    )
  }, character( 1L ) )

  samp_sig = vapply( sts, function( st ) {
    paste( prop( st, "outcome" ), paste( prop( st, "samplings" ), collapse = "," ), sep = ":" )
  }, character( 1L ) )

  ic_sig = if ( length( ic ) )
    paste( names( ic ), vapply( ic, as.character, character( 1L ) ), sep = "=", collapse = ";" )
  else ""

  paste( paste( dose_sig, collapse = ";" ), paste( samp_sig, collapse = ";" ), ic_sig, sep = "||" )
}

.pfimGradAdminCacheKey = function( model, arm ) {
  cls = class( model )[[ 1L ]]
  param_names = paste( map_chr( prop( model, "modelParameters" ), ~ prop( .x, "name" ) ), collapse = "," )
  paste( cls, param_names, .pfimArmAdminSignature( arm ), sep = "::" )
}

.pfimShiftModelParameters = function( parameters, shiftedCol ) {
  map2( parameters, shiftedCol, function( param, newMu ) {
    distr = prop( param, "distribution" )
    prop( distr, "mu" ) <- newMu
    prop( param, "distribution" ) <- distr
    param
  } )
}

.pfimFiniteDifferenceHessianCached = function( model ) {
  if ( !.pfimPerfOption( "PFIM.perf.fdCache", TRUE ) )
    return( finiteDifferenceHessian( model ) )

  key = .pfimMuSignature( prop( model, "modelParameters" ) )
  cached = .PFIM_FD_SCHEME_CACHE[[ key ]]
  if ( !is.null( cached ) ) {
    prop( model, "parametersForComputingGradient" ) <- cached
    return( model )
  }

  model = finiteDifferenceHessian( model )
  .PFIM_FD_SCHEME_CACHE[[ key ]] = prop( model, "parametersForComputingGradient" )
  model
}

.pfimUseParallelGradients = function( nTasks ) {
  isTRUE( getOption( "PFIM.parallel.gradients", FALSE ) ) &&
    nTasks > 1L &&
    !.pfimInParallelWorker() &&
    !isTRUE( getOption( "PFIM.parallel", FALSE ) ) &&
    .pfimParallelWorkers() > 1L &&
    .pfimParallelPkgsAvailable()
}

.pfimParallelMapGradients = function( .x, .f, ... ) {
  if ( !.pfimUseParallelGradients( length( .x ) ) )
    return( purrr::map( .x, .f, ... ) )

  precheck = .pfimParallelPrecheck( strict = isTRUE( getOption( "PFIM.parallel.strict", FALSE ) ) )
  if ( isFALSE( precheck ) )
    return( purrr::map( .x, .f, ... ) )

  old_plan = future::plan()
  on.exit( future::plan( old_plan ), add = TRUE )
  workers = .pfimParallelWorkers()
  future::plan( future::multisession, workers = workers )

  pfim_ns     = asNamespace( "PFIM" )
  worker_init = get( ".pfimParallelWorkerInit", envir = pfim_ns, inherits = FALSE )
  init_flag   = .PFIM_WORKER_INIT_FLAG
  pkg_root    = .pfimParallelWorkerPkgRoot()

  .pfimMuffleRelayedWorkerWarnings(
    furrr::future_map(
      .x,
      function( item, ... ) {
        options( PFIM.inWorker = TRUE )
        worker_state = get( ".PFIM_PARALLEL_STATE", envir = asNamespace( "PFIM" ) )
        if ( !isTRUE( get0( init_flag, envir = worker_state, inherits = FALSE ) ) ) {
          suppressWarnings( worker_init( pkg_root ) )
          assign( init_flag, TRUE, envir = worker_state )
        }
        .f( item, ... )
      },
      ...,
      .options = furrr::furrr_options( globals = TRUE, seed = FALSE )
    )
  )
}

.pfimIsOdeModelClass = function( model ) {
  S7::S7_inherits( model, ModelODE )
}

.pfimOdeSimTimesCached = function( cacheKey, raw_samplings, events_df ) {
  if ( .pfimPerfOption( "PFIM.perf.odeTimesCache", TRUE ) &&
       !is.null( .PFIM_ODE_SIM_GRID[[ cacheKey ]] ) )
    return( .PFIM_ODE_SIM_GRID[[ cacheKey ]] )

  sim_times = sort( unique( c( raw_samplings, if ( !is.null( events_df ) ) events_df$time else numeric( 0 ) ) ) )
  sim_times = sim_times[ c( TRUE, diff( sim_times ) > 1e-8 ) ]

  if ( .pfimPerfOption( "PFIM.perf.odeTimesCache", TRUE ) )
    .PFIM_ODE_SIM_GRID[[ cacheKey ]] = sim_times

  sim_times
}

.pfimDefineModelAdministrationCached = function( model, arm ) {
  if ( !.pfimPerfOption( "PFIM.perf.adminCache", TRUE ) || !.pfimIsOdeModelClass( model ) )
    return( defineModelAdministration( model, arm ) )

  key   = .pfimGradAdminCacheKey( model, arm )
  entry = .PFIM_GRAD_ADMIN_CACHE[[ key ]]

  if ( is.null( entry ) ) {
    model = defineModelAdministration( model, arm )
    .PFIM_GRAD_ADMIN_CACHE[[ key ]] = .pfimCaptureOdeAdminEntry( model, arm )
    return( model )
  }

  .pfimRefreshOdeAdministration( model, arm, entry )
}

.pfimCaptureOdeAdminEntry = function( model, arm ) {
  if ( S7::S7_inherits( model, ModelODEBolus ) ) {
    return( list(
      type                 = "bolus",
      samplings            = prop( model, "samplings" ),
      doseEventTemplate    = .odeBolusDoseEventTemplate( arm, prop( model, "samplings" ) ),
      initialConditionsTmp = prop( arm, "initialConditions" ),
      wrapper              = prop( model, "wrapper" ),
      functionArguments    = prop( model, "functionArguments" ),
      functionArgumentsSymbols = prop( model, "functionArgumentsSymbol" ),
      outputFormula        = map( prop( model, "outputFormula" ), ~ parse( text = .x ) )
    ) )
  }

  if ( S7::S7_inherits( model, ModelODEDoseNotInEquations ) ) {
    return( list(
      type                 = "doseNotInEq",
      samplings            = prop( model, "samplings" ),
      doseEventTemplate    = .odeBolusDoseEventTemplate( arm, prop( model, "samplings" ) ),
      wrapper              = prop( model, "wrapper" ),
      functionArguments    = prop( model, "functionArguments" ),
      functionArgumentsSymbols = prop( model, "functionArgumentsSymbol" ),
      outputFormula        = map( prop( model, "outputFormula" ), ~ parse( text = .x ) )
    ) )
  }

  if ( S7::S7_inherits( model, ModelODEDoseInEquations ) ) {
    return( list(
      type                       = "doseInEq",
      samplings                  = prop( model, "samplings" ),
      solverInputs               = prop( model, "solverInputs" ),
      outcomesWithAdministration = prop( model, "outcomesWithAdministration" ),
      wrapper                    = prop( model, "wrapper" ),
      functionArguments          = prop( model, "functionArguments" ),
      functionArgumentsSymbols   = prop( model, "functionArgumentsSymbol" ),
      outputFormula              = map( prop( model, "outputFormula" ), ~ parse( text = .x ) )
    ) )
  }

  list( type = "full" )
}

.pfimRefreshOdeAdministration = function( model, arm, entry ) {
  mu = .extractMu( prop( model, "modelParameters" ) )

  if ( entry$type == "bolus" ) {
    doseEvent = entry$doseEventTemplate
    initialConditions = evaluateInitialConditions( model, arm, doseEvent )

    initialConditionsTmp = entry$initialConditionsTmp
    env = list2env( as.list( mu ), parent = environment() )
    walk( seq_len( nrow( doseEvent ) ), function( iter ) {
      outcomeName = doseEvent$var[ iter ]
      ic_expr = initialConditionsTmp[[ outcomeName ]]
      if ( is.null( ic_expr ) ) return( invisible( NULL ) )
      assign( paste0( "dose_", outcomeName ), doseEvent$value[ iter ], envir = env )
      doseEvent$value[ iter ] <<- eval( parse( text = ic_expr ), envir = env )
    } )

    model = .odeBolusFinalizeAdministration(
      model, mu, doseEvent, initialConditions, entry$samplings,
      entry$wrapper, entry$functionArguments, entry$functionArgumentsSymbols, entry$outputFormula
    )
    return( model )
  }

  if ( entry$type == "doseNotInEq" ) {
    doseEvent = entry$doseEventTemplate
    initialConditions = evaluateInitialConditions( model, arm )
    initialConditionsAdmin = set_names(
      rep( 0, length( unique( doseEvent$var[ doseEvent$time == 0 ] ) ) ),
      unique( doseEvent$var[ doseEvent$time == 0 ] )
    )
    initialConditions = c( initialConditionsAdmin, initialConditions )
    initialConditions = initialConditions[ !duplicated( names( initialConditions ) ) ]
    model = .odeDoseNotInEqFinalizeAdministration(
      model, mu, doseEvent, initialConditions, entry$samplings,
      entry$wrapper, entry$functionArguments, entry$functionArgumentsSymbols, entry$outputFormula
    )
    return( model )
  }

  if ( entry$type == "doseInEq" ) {
    initialConditions = evaluateInitialConditions( model, arm )
    model = .odeDoseInEqFinalizeAdministration(
      model, mu, initialConditions, entry$samplings, entry$solverInputs,
      entry$outcomesWithAdministration, entry$wrapper, entry$functionArguments,
      entry$functionArgumentsSymbols, entry$outputFormula
    )
    return( model )
  }

  defineModelAdministration( model, arm )
}

.pfimPrepareModelForEvaluation = function( model, arm ) {
  .pfimDefineModelAdministrationCached( model, arm )
}

.pfimClearGradientPerfCaches = function() {
  rm( list = ls( .PFIM_FD_SCHEME_CACHE, all.names = TRUE ), envir = .PFIM_FD_SCHEME_CACHE )
  rm( list = ls( .PFIM_GRAD_ADMIN_CACHE, all.names = TRUE ), envir = .PFIM_GRAD_ADMIN_CACHE )
  rm( list = ls( .PFIM_ODE_SIM_GRID, all.names = TRUE ), envir = .PFIM_ODE_SIM_GRID )
  invisible( NULL )
}

.pfimGradientPerfStatus = function() {
  list(
    parallel_gradients = isTRUE( getOption( "PFIM.parallel.gradients", FALSE ) ),
    admin_cache        = .pfimPerfOption( "PFIM.perf.adminCache", TRUE ),
    fd_cache           = .pfimPerfOption( "PFIM.perf.fdCache", TRUE ),
    ode_times_cache    = .pfimPerfOption( "PFIM.perf.odeTimesCache", TRUE ),
    fd_cache_size      = length( ls( .PFIM_FD_SCHEME_CACHE, all.names = TRUE ) ),
    admin_cache_size   = length( ls( .PFIM_GRAD_ADMIN_CACHE, all.names = TRUE ) ),
    ode_times_cache_size = length( ls( .PFIM_ODE_SIM_GRID, all.names = TRUE ) )
  )
}
