# User-facing parallel FIM configuration (future / furrr).

#' Configure parallel FIM evaluation (plug-and-play)
#'
#' Sets \code{options(PFIM.parallel)}, worker count, and core reserve, then
#' optionally validates that background workers can load PFIM.
#'
#' @param parallel Logical; enable parallel FIM evaluation. Default \code{TRUE}.
#' @param workers Number of parallel workers. Default: auto
#'   (\code{availableCores() - cores.reserve}, capped sensibly).
#' @param cores.reserve Cores left free for the OS (default \code{2}).
#' @param strict If \code{TRUE}, stop when parallel prerequisites are missing.
#'   If \code{FALSE} (default), fall back to sequential evaluation with a warning.
#' @param validate If \code{TRUE} (default), run a short worker smoke test.
#' @param quiet If \code{FALSE}, print a one-line summary of the configuration.
#' @param parallel.gradients If not \code{NULL}, set \code{options(PFIM.parallel.gradients)}.
#'   Parallelises finite-difference perturbations (disabled when \code{PFIM.parallel} is active).
#' @return Invisibly, a list with \code{parallel}, \code{workers}, \code{ready}.
#' @section Windows:
#' Workers use \code{future::multisession} and load the installed PFIM DLL.
#' During development, set \code{options(PFIM.devPath)} and reinstall after C++
#' changes; see \code{vignette("ParallelFIM")}.
#' @export
#' @examples
#' \dontrun{
#' configureParallel(workers = 4)
#' optimization = run(myOptimization)
#' }
configureParallel = function(
    parallel       = TRUE,
    workers        = NULL,
    cores.reserve  = 2L,
    strict         = FALSE,
    validate       = TRUE,
    quiet          = FALSE,
    parallel.gradients = NULL ) {

  if ( !is.logical( parallel ) || length( parallel ) != 1L )
    stop( "parallel must be a single logical value.", call. = FALSE )

  options(
    PFIM.parallel      = parallel,
    PFIM.cores.reserve = as.integer( cores.reserve ),
    PFIM.parallel.strict = isTRUE( strict ),
    PFIM.parallel.validated = FALSE
  )

  if ( !is.null( workers ) )
    options( PFIM.workers = as.integer( workers ) )

  if ( !is.null( parallel.gradients ) )
    options( PFIM.parallel.gradients = isTRUE( parallel.gradients ) )

  ready = FALSE
  workers_eff = if ( parallel ) .pfimParallelWorkers() else 0L

  if ( parallel ) {
    missing_pkgs = .pfimMissingParallelPkgs()
    if ( length( missing_pkgs ) ) {
      msg = paste0(
        "Parallel packages missing: ", paste( missing_pkgs, collapse = ", " ), ". ",
        "Install with install.packages(c('future', 'furrr')) or set parallel = FALSE."
      )
      if ( strict ) stop( msg, call. = FALSE )
      warning( msg, "\nFalling back to sequential FIM evaluation.", call. = FALSE )
      options( PFIM.parallel = FALSE )
      workers_eff = 0L
    } else if ( workers_eff <= 1L ) {
      msg = "Only one worker is available; parallel FIM is disabled."
      if ( strict ) stop( msg, call. = FALSE )
      warning( msg, call. = FALSE )
      options( PFIM.parallel = FALSE )
      workers_eff = 0L
    } else {
      .pfimParallelPrecheck( strict = strict )
      if ( validate )
        ready = isTRUE( .pfimParallelSmokeTest( workers_eff, quiet = quiet ) )
      else
        ready = TRUE
      if ( validate && ready )
        options( PFIM.parallel.validated = TRUE )
    }
  }

  if ( !quiet ) {
    if ( isTRUE( getOption( "PFIM.parallel", FALSE ) ) )
      message( sprintf(
        "PFIM parallel: %d workers (%d cores reserved for the OS)%s",
        workers_eff,
        as.integer( getOption( "PFIM.cores.reserve", 2L ) ),
        if ( validate && ready ) " - workers OK" else if ( validate ) " - worker check skipped/failed" else ""
      ) )
    else
      message( "PFIM parallel: off (sequential FIM evaluation)" )
  }

  invisible( list(
    parallel = isTRUE( getOption( "PFIM.parallel", FALSE ) ),
    workers  = workers_eff,
    ready    = ready
  ) )
}

#' Parallel FIM status and diagnostics
#'
#' @return A list describing packages, workers, installed PFIM, and dev path.
#' @export
#' @examples
#' parallelStatus()
parallelStatus = function() {
  pkg_root = .pfimPackageRoot()
  list(
    parallel_enabled   = isTRUE( getOption( "PFIM.parallel", FALSE ) ),
    strict             = isTRUE( getOption( "PFIM.parallel.strict", FALSE ) ),
    workers_requested  = getOption( "PFIM.workers", NA ),
    workers_effective  = if ( isTRUE( getOption( "PFIM.parallel", FALSE ) ) )
      .pfimParallelWorkers() else 0L,
    cores_reserve      = .pfimCoresReserve(),
    available_cores    = .pfimAvailableCores(),
    future_installed   = requireNamespace( "future", quietly = TRUE ),
    furrr_installed    = requireNamespace( "furrr", quietly = TRUE ),
    pfim_installed     = requireNamespace( "PFIM", quietly = TRUE ),
    pfim_loaded        = "PFIM" %in% .packages(),
    package_root       = pkg_root,
    dynlib_path        = .pfimDynlibPath( pkg_root ),
    in_worker          = .pfimInParallelWorker(),
    fim_cache          = .pfimFimCacheStats(),
    gradient_perf      = .pfimGradientPerfStatus()
  )
}

#' @keywords internal
.pfimParallelSmokeTest = function( workers, quiet = TRUE ) {
  if ( .pfimInParallelWorker() )
    return( TRUE )
  if ( !requireNamespace( "future", quietly = TRUE ) )
    return( FALSE )

  old_plan = future::plan()
  on.exit( future::plan( old_plan ), add = TRUE )
  n = max( 1L, min( as.integer( workers ), 2L ) )
  future::plan( future::multisession, workers = n )

  pfim_ns   = asNamespace( "PFIM" )
  init      = get( ".pfimParallelWorkerInit", envir = pfim_ns, inherits = FALSE )
  pkg_root  = get( ".pfimParallelWorkerPkgRoot", envir = pfim_ns, inherits = FALSE )()

  ok = .pfimMuffleRelayedWorkerWarnings( tryCatch(
    {
      f = future::future({
        options( PFIM.inWorker = TRUE )
        suppressWarnings( init( pkg_root ) )
        "PFIM" %in% loadedNamespaces() &&
          nzchar( system.file( "DESCRIPTION", package = "PFIM" ) )
      }, globals = list( init = init, pkg_root = pkg_root ) )
      isTRUE( future::value( f ) )
    },
    error = function( e ) {
      if ( !quiet )
        message( "PFIM parallel worker check failed: ", conditionMessage( e ) )
      FALSE
    }
  ) )

  if ( !ok && !quiet )
    message(
      "PFIM parallel: workers could not load PFIM. ",
      "Restart R, run devtools::install(quick = TRUE), then configureParallel()."
    )
  ok
}

#' @keywords internal
.pfimParallelAutoSetup = function() {
  if ( !is.null( getOption( "PFIM.parallel" ) ) )
    return( invisible( NULL ) )
  if ( length( .pfimMissingParallelPkgs() ) )
    return( invisible( NULL ) )
  configureParallel( validate = FALSE, quiet = TRUE )
  invisible( NULL )
}

#' @keywords internal
.pfimEnsureParallelReady = function() {
  if ( !isTRUE( getOption( "PFIM.parallel", FALSE ) ) )
    return( invisible( FALSE ) )
  if ( isTRUE( getOption( "PFIM.parallel.validated", FALSE ) ) )
    return( invisible( TRUE ) )

  precheck = .pfimParallelPrecheck(
    strict = isTRUE( getOption( "PFIM.parallel.strict", FALSE ) )
  )
  if ( isFALSE( precheck ) )
    return( invisible( FALSE ) )

  ok = isTRUE( .pfimParallelSmokeTest( .pfimParallelWorkers(), quiet = TRUE ) )
  if ( ok ) {
    options( PFIM.parallel.validated = TRUE )
    return( invisible( TRUE ) )
  }

  msg = paste0(
    "Parallel workers could not load PFIM. Restart R, run ",
    "devtools::install(quick = TRUE), then configureParallel()."
  )
  if ( isTRUE( getOption( "PFIM.parallel.strict", FALSE ) ) )
    stop( msg, call. = FALSE )
  warning( msg, "\nFalling back to sequential FIM evaluation.", call. = FALSE )
  options( PFIM.parallel = FALSE )
  invisible( FALSE )
}
