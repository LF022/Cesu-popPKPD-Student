#' @title ModelODEDoseNotInEquations
#' @description ODE model with bolus dose as a compartment event (not in equations).
#' @inheritParams ModelODE
#' @param modelODE     A function: the compiled ODE solver function.
#' @param doseEvent    A list: dose events for the ODE solver.
#' @param solverInputs A list: solver inputs.
#' @include Model.R
#' @export

ModelODEDoseNotInEquations = new_class( "ModelODEDoseNotInEquations",
                                        package = "PFIM",
                                        parent  = ModelODE,
                                        properties = list(
                                          modelODE     = new_property(class_function, default = NULL),
                                          doseEvent    = new_property(class_list,     default = list()),
                                          solverInputs = new_property(class_list,     default = list())
                                        ))

# ==============================================================================
#' defineModelWrapper: build the ODE wrapper for the dose-as-compartment model.
#' @name defineModelWrapper
#' @param model      A \code{ModelODEDoseNotInEquations} object.
#' @param evaluation An \code{Evaluation} object.
#' @return The model with updated properties.
# ==============================================================================

method( defineModelWrapper, ModelODEDoseNotInEquations ) = function( model, evaluation ) {

  equations              = prop( evaluation, "modelEquations" )
  variableNames          = str_remove( names( equations ), "Deriv_" )
  parameterNames         = map_chr( prop( evaluation, "modelParameters" ), "name" )
  functionArguments      = unique( c( parameterNames, variableNames, "t" ) )
  functionArgumentsSymbols = map( functionArguments, as.symbol )

  outputs = prop( evaluation, "outputs" )
  prop( model, "outputFormula" ) <- outputs
  prop( model, "outputNames" ) <- names( outputs )
  prop( model, "wrapper" ) <- .buildODEWrapper( equations, functionArguments )
  prop( model, "functionArguments" ) <- functionArguments
  prop( model, "functionArgumentsSymbol" ) <- functionArgumentsSymbols

  return( model )
}

# ==============================================================================
# Internal administration builders (shared with gradient performance cache).
# ==============================================================================

#' @keywords internal
.odeDoseNotInEqFinalizeAdministration = function(
    model, mu, doseEvent, initialConditions, samplings,
    wrapper, functionArguments, functionArgumentsSymbols, outputFormula ) {

  modelODEDoseAsCmpt = function( t, y, parms ) {
    with( as.list( c( t = t, y, mu ) ), {
      evaluationModel   = do.call( wrapper, set_names( functionArgumentsSymbols, functionArguments ) )
      evaluationOutputs = map( outputFormula, ~ eval( .x ) )
      return( c( evaluationModel, evaluationOutputs ) )
    } )
  }

  prop( model, "initialConditions" ) <- initialConditions
  prop( model, "samplings" ) <- samplings
  prop( model, "modelODE" ) <- modelODEDoseAsCmpt
  prop( model, "doseEvent" ) <- doseEvent
  model
}

# ==============================================================================
#' defineModelAdministration: build the dose event table and ODE function.
#' @name defineModelAdministration
#' @param model A \code{ModelODEDoseNotInEquations} object.
#' @param arm   An \code{Arm} object.
#' @return The model with updated properties.
#' @export
# ==============================================================================

method( defineModelAdministration, ModelODEDoseNotInEquations ) = function( model, arm ) {

  samplingTimes            = prop( arm,   "samplingTimes" )
  samplings                = .buildSamplings( samplingTimes )
  wrapper                  = prop( model, "wrapper" )
  parameters               = prop( model, "modelParameters" )
  functionArguments        = prop( model, "functionArguments" )
  functionArgumentsSymbols = prop( model, "functionArgumentsSymbol" )
  outputFormula            = map( prop( model, "outputFormula" ), ~ parse( text = .x ) )
  mu                       = .extractMu( parameters )

  doseEvent = .odeBolusDoseEventTemplate( arm, samplings )
  initialConditions = evaluateInitialConditions( model, arm )
  initialConditionsAdmin = set_names(
    rep( 0, length( unique( doseEvent$var[ doseEvent$time == 0 ] ) ) ),
    unique( doseEvent$var[ doseEvent$time == 0 ] )
  )
  initialConditions = c( initialConditionsAdmin, initialConditions )
  initialConditions = initialConditions[ !duplicated( names( initialConditions ) ) ]

  .odeDoseNotInEqFinalizeAdministration(
    model, mu, doseEvent, initialConditions, samplings,
    wrapper, functionArguments, functionArgumentsSymbols, outputFormula
  )
}

# ==============================================================================
#' evaluateModel: solve the dose-as-compartment ODE model.
#' @name evaluateModel
#' @param model A \code{ModelODEDoseNotInEquations} object.
#' @param arm   An \code{Arm} object.
#' @return A named list of data frames, one per output.
#' @export
# ==============================================================================

method( evaluateModel, ModelODEDoseNotInEquations ) = function( model, arm ) {

  evaluateCore = function( model, arm ) {
    odeSolverParameters = prop( model, "odeSolverParameters" )
    outputNames         = prop( model, "outputNames" )
    samplingTimes       = prop( arm,   "samplingTimes" )

    raw_samplings = prop( model, "samplings" )
    events_df     = prop( model, "doseEvent" )
    sim_key       = paste(
      "doseNotInEq", paste( raw_samplings, collapse = "," ),
      paste( events_df$time, events_df$value, sep = ":", collapse = "," ),
      sep = "::"
    )
    sim_times = .pfimOdeSimTimesCached( sim_key, raw_samplings, events_df )

    evaluationModelTmp = ode(
      prop( model, "initialConditions" ),
      sim_times,
      prop( model, "modelODE" ),
      NULL,
      events = list( data = events_df ),
      atol   = odeSolverParameters$atol,
      rtol   = odeSolverParameters$rtol
    ) |> as.data.frame()

    .odeExtractOutputAtSamplingTimes( evaluationModelTmp, samplingTimes, outputNames )
  }

  if ( usesCovariateOccasionStructure( model ) )
    evaluateModelWithCovariates( model, arm, evaluateCore )
  else
    evaluateCore( model, arm )
}
# ==============================================================================
#' definePKModel
#' @name definePKModel
#' @param pkModel     A \code{ModelODEDoseNotInEquations} object.
#' @param pfimproject A \code{PFIMProject} object.
#' @export
# ==============================================================================

method( definePKModel, list( ModelODEDoseNotInEquations, PFIMProject ) ) = function( pkModel, pfimproject ) {
  prop( pkModel, "modelEquations" )
}
