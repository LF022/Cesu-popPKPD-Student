#' @title PGBOAlgorithm
#' @description
#' Population-based global optimization for sampling times (Rcpp kernel).
#' @param N Numeric: the parameter N.
#' @param muteEffect Numeric: the parameter muteEffect.
#' @param maxIteration Numeric: the parameter maxIteration.
#' @param purgeIteration Numeric: the parameter purgeIteration.
#' @param seed Numeric: the parameter seed.
#' @param showProcess Logical: showProcess.
#' @param fitBase Numeric: baseline fitness for PGBO (default 0.03).
#' @include Optimization.R
#' @export

PGBOAlgorithm = new_class( "PGBOAlgorithm", package = "PFIM",

                           properties = list( N = new_property(class_double, default = numeric(0)),
                                              muteEffect = new_property(class_double, default = numeric(0)),
                                              maxIteration = new_property(class_double, default = numeric(0)),
                                              purgeIteration = new_property(class_double, default = numeric(0)),
                                              fitBase = new_property(class_double, default = 0.03),
                                              seed = new_property(class_double, default = numeric(0)),
                                              showProcess = new_property(class_logical, default = FALSE )))
S4_register( PGBOAlgorithm )

# ==============================================================================
#' Population Genetics Based Optimization kernel (Rcpp).
#'
#' Compiled implementation in \code{src/Pgboalgorithm.cpp}. FIM evaluation and
#' per-group constraint checks are R callbacks.
#'
#' @name pgbo_optimize_Rcpp
#' @keywords internal
NULL

# ==============================================================================
#' Optimization PGBOAlgorithm
#' @name optimizeDesign
#' @param optimizationObject An object \code{Optimization}.
#' @param optimizationAlgorithm An object \code{PGBOAlgorithm}.
#' @return The object \code{optimizationObject} with the slots updated.
#' @export
# ==============================================================================

method( optimizeDesign, list( Optimization, PGBOAlgorithm ) ) = function( optimizationObject, optimizationAlgorithm ) {

  design = pluck( projectProp( optimizationObject, "designs" ), 1L )
  checkValiditySamplingConstraint( design )
  design = setSamplingConstraintForOptimization( design )

  optimizerParameters = projectProp( optimizationObject, "optimizerParameters" )
  set.seed( optimizerParameters$seed )

  arms     = prop( design, "arms" )
  outcomes = map( set_names( arms, map_chr( arms, ~ prop( .x, 'name' ) ) ), ~ map_chr( prop( .x, "samplingTimesConstraints" ), ~ prop( .x, "outcome") ) )

  initialArms = map( arms, function( arm ) {
    samplingConstraints = prop( arm, "samplingTimesConstraints" )

    newSamplings = map( samplingConstraints, ~ generateSamplingsFromSamplingConstraints( .x ) ) |>
      set_names( map_chr( samplingConstraints, ~ prop( .x, "outcome" ) ) )

    updatedTimes = map( prop( arm, "samplingTimes" ), function( st ) {
      outcome = prop( st, "outcome" )
      if ( outcome %in% names( newSamplings ) ) prop( st, "samplings" ) <- newSamplings[[ outcome ]]
      st
    })

    prop( arm, "samplingTimes" ) <- updatedTimes
    arm
  })

  prop( design, "arms" ) <- initialArms
  initialDesign = design

  layout = .buildFlatSamplingLayout( design )

  evalObjTemplate = Evaluation(
    name                    = "",
    modelEquations          = projectProp( optimizationObject, "modelEquations" ),
    modelParameters         = projectProp( optimizationObject, "modelParameters" ),
    modelError              = projectProp( optimizationObject, "modelError" ),
    modelCovariates         = projectProp( optimizationObject, "modelCovariates" ),
    modelCovariatesEquation = projectProp( optimizationObject, "modelCovariatesEquation" ),
    fimType                 = projectProp( optimizationObject, "fimType" ),
    outputs                 = projectProp( optimizationObject, "outputs" ),
    designs                 = list( design ),
    odeSolverParameters     = projectProp( optimizationObject, "odeSolverParameters" )
  )

  flat_from_design = function( tgt_design ) {
    .buildFlatSamplingLayout( tgt_design )$initial_flat
  }

  eval_d = function( flat_pos ) {
    newArms = .applyFlatToArms( flat_pos, arms )

    tempDesign = design
    prop( tempDesign, "arms" ) <- newArms
    prop( evalObjTemplate, "designs" ) <- list( tempDesign )

    fim = prop( run( evalObjTemplate ), "fim" )
    d   = 1 / Dcriterion( fim )
    if ( !is.finite( d ) ) .metaheuristicFitnessPenalty else d
  }

  check_valid_group = function( flat_pos, group_id ) {
    .checkFlatValidGroup( layout, flat_pos, group_id )
  }

  fitBase = prop( optimizationAlgorithm, "fitBase" )

  res_cpp = pgbo_optimize_Rcpp(
    initial_pos        = flat_from_design( initialDesign ),
    sorting_groups     = layout$sorting_groups,
    max_iteration      = as.integer( optimizerParameters$maxIteration ),
    N                  = as.integer( optimizerParameters$N ),
    mute_effect        = optimizerParameters$muteEffect,
    purge_iteration    = as.integer( optimizerParameters$purgeIteration ),
    fit_base           = fitBase,
    max_attempts       = 10000L,
    show_process       = optimizerParameters$showProcess,
    eval_d             = eval_d,
    check_valid_group  = check_valid_group
  )

  best_flat = res_cpp$bestDesign

  finalArms = .applyFlatToArms( best_flat, arms )

  optimalDesign = design
  prop( optimalDesign, "arms" ) <- finalArms

  evaluateFinal = function( finalDesign ) {
    evalObj = Evaluation(
      name                    = "",
      modelEquations          = projectProp( optimizationObject, "modelEquations" ),
      modelParameters         = projectProp( optimizationObject, "modelParameters" ),
      modelError              = projectProp( optimizationObject, "modelError" ),
      modelCovariates         = projectProp( optimizationObject, "modelCovariates" ),
      modelCovariatesEquation = projectProp( optimizationObject, "modelCovariatesEquation" ),
      designs                 = list( finalDesign ),
      fimType                 = projectProp( optimizationObject, "fimType" ),
      outputs                 = projectProp( optimizationObject, "outputs" ),
      odeSolverParameters     = projectProp( optimizationObject, "odeSolverParameters" )
    )
    run( evalObj )
  }

  prop( optimizationObject, "optimisationDesign" ) <- list(
    evaluationInitialDesign = evaluateFinal( initialDesign ),
    evaluationOptimalDesign = evaluateFinal( optimalDesign )
  )
  prop( optimizationObject, "optimisationAlgorithmOutputs" ) <- list(
    "optimizationAlgorithm" = optimizationAlgorithm,
    "optimalArms"           = finalArms
  )

  optimizationObject
}

# ==============================================================================
#' constraintsTableForReport: table of the PGBOAlgorithm constraints for the report.
#' @name constraintsTableForReport
#' @param optimizationAlgorithm An object \code{PGBOAlgorithm}.
#' @param arms List of the arms.
#' @return The table for the constraints in the arms.
#' @export
# ==============================================================================

method( constraintsTableForReport, PGBOAlgorithm ) = function( optimizationAlgorithm, arms  )
{
  armsConstraints = map( pluck( arms, 1 ) , ~ getArmConstraints( .x, optimizationAlgorithm ) )
  armsConstraints = .constraintsArmsTable( armsConstraints )
  colnames( armsConstraints ) = c( "Arms name" , "Number of subjects", "Outcome", "Initial samplings", "Samplings windows", "Number of times by windows","Min sampling" )
  armsConstraintsTable = kbl( armsConstraints, align = c( "l","c","c","c","c","c","c") ) |>
    kable_styling( bootstrap_options = c( "hover" ), full_width = FALSE, position = "center", font_size = 13 )
  return( armsConstraintsTable )
}
