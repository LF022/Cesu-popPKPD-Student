# Arm evaluation plots and sensitivity-index processing.
# @include Arm.R

#' @keywords internal
.normalizePlotOptions = function( plotOptions, outputNames ) {
  unitTime = plotOptions$unitTime
  if ( is.null( unitTime ) || length( unitTime ) == 0L )
    unitTime = " "
  else if ( length( unitTime ) > 1L )
    unitTime = unitTime[[ 1L ]]

  out = unlist( outputNames, use.names = FALSE )
  if ( length( out ) == 0L )
    out = names( outputNames )

  raw = plotOptions$unitOutcomes
  if ( is.null( raw ) || length( raw ) == 0L ) {
    unitOutcomes = stats::setNames( rep( " ", length( out ) ), out )
  } else {
    raw = as.character( unlist( raw, use.names = FALSE ) )
    if ( length( raw ) == 1L && length( out ) > 1L )
      raw = rep( raw, length( out ) )
    unitOutcomes = stats::setNames( raw[ seq_along( out ) ], out )
  }

  list( unitTime = unitTime, unitOutcomes = unitOutcomes )
}

# ==============================================================================
#' processArmEvaluationResults: process for the evaluation of an arm.
#' @name processArmEvaluationResults
#' @param arm An \code{Arm} object.
#' @param model A \code{Model} object.
#' @param fim A \code{Fim} object.
#' @param designName Character string: name of the design.
#' @param plotOptions A list with the plot options.
#' @return Nested list of \code{ggplot} objects for model responses.
#' @export
# ==============================================================================

method( processArmEvaluationResults, list( Arm, Model, Fim ) ) = function( arm, model, fim, designName, plotOptions ) {

  outputNames = as.list(prop(model, "outputNames"))

  samplingData = getSamplingData(arm)
  arm = updateSamplingTimes(arm, samplingData)
  model = defineModelAdministration(model, arm)
  evaluationModel = evaluateModel(model, arm)
  plots = plotEvaluationResults( arm, evaluationModel, outputNames, samplingData, designName, plotOptions )
  return(plots)
}

# ==============================================================================
#' processArmEvaluationSI: process for the evaluation of the gradient of the responses.
#' @name processArmEvaluationSI
#' @param arm An \code{Arm} object.
#' @param model A \code{Model} object.
#' @param fim A \code{Fim} object.
#' @param designName Character string: name of the design.
#' @return A list with the ggplot object of the plots of the gradient.
#' @export
# ==============================================================================

method( processArmEvaluationSI, list( Arm, Model, Fim ) ) = function( arm, model, fim, designName, plotOptions ) {

  outputNames = as.list(prop(model, "outputNames"))

  samplingData = getSamplingData(arm)
  arm = updateSamplingTimes(arm, samplingData)
  model = defineModelAdministration(model, arm)
  parametersNames = prop(model, "modelParameters") |> map_chr(~ prop(.x, "name"))
  evaluationModelGradient = evaluateModelGradient(model, arm)
  timeSeq = seq(from = 0, by = 0.1, length.out = nrow( pluck( evaluationModelGradient, 1 ) ) )
  evaluationModelGradient = map2(outputNames, evaluationModelGradient, function(outputName, gradient) { data.frame(time = timeSeq, gradient) }) |> set_names(outputNames)

  plots = plotEvaluationSI( arm, evaluationModelGradient, parametersNames, outputNames, samplingData, designName, plotOptions )
  return(plots)
}

# ==============================================================================
#' plotEvaluationResults: process for the evaluation of the responses.
#' @name plotEvaluationResults
#' @param arm An \code{Arm} object.
#' @param evaluationModel A list with the evaluation of the model.
#' @param outputNames Character vector of output names.
#' @param samplingData A list with the sampling data from the method getSamplingData.
#' @param unitXAxis A list with the unit of the x-axis.
#' @param unitYAxis A list with the unit of the y-axis.
#' @param designName Character string: design name.
#' @return A list with the plot of the evaluation of the model responses.
#' @export
# ==============================================================================

method( plotEvaluationResults, Arm ) = function( arm, evaluationModel, outputNames, samplingData, designName, plotOptions ) {

  units     = .normalizePlotOptions( plotOptions, outputNames )
  unitXAxis = units$unitTime
  unitYAxis = units$unitOutcomes
  plotList = list()
  armName = prop( arm, "name")
  plotList[[designName]] = list()
  plotList[[designName]][[armName]] = list()

  plots =  map2(outputNames, samplingData$samplings, function(outputName, sampling) {

    data = evaluationModel[[outputName]]

    samplingPoints = data[data$time %in% sampling, ]

    ggplot(data, aes(x = time, y = .data[[outputName]])) +
      geom_line() +
      geom_point(data = samplingPoints, aes(x = time, y = .data[[outputName]]), color = "red") +
      labs( x = paste0("Time (", unitXAxis, ")\n\nDesign: ", sub("_", " ", designName), "      Arm: ", armName ),
            y = paste0(outputName, " (", unitYAxis[[outputName]], ")\n" ) ) +
      scale_x_continuous(breaks = pretty_breaks(n = 10), sec.axis = sec_axis(~ . * 1, breaks = round(sampling, 2), name = "Sampling times")) +
      scale_y_continuous(breaks = pretty_breaks(n = 10)) +
      theme( legend.position = "none",
             axis.title.x.top = element_text(color = "red", vjust = 2.0),
             axis.text.x.top = element_text(angle = 90, hjust = 0, color = "red"),
             plot.title = element_text(size = 16, hjust = 0.5),
             axis.title.x = element_text(size = 16),
             axis.title.y = element_text(size = 16),
             axis.text.x = element_text(size = 16, angle = 90, vjust = 0.5),
             axis.text.y = element_text(size = 16, angle = 0, vjust = 0.5, hjust = 0.5),
             strip.text.x = element_text(size = 16) )
  })

  plotList[[designName]][[armName]] = set_names( plots, outputNames )
  return( plotList )
}

# ==============================================================================
#' plotEvaluationSI: process for the evaluation of the gradient of the responses.
#' @name plotEvaluationSI
#' @param arm An \code{Arm} object.
#' @param evaluationModelGradient A list with the evaluation of the gradient of the model responses.
#' @param parametersNames Character vector of parameter names.
#' @param outputNames Character vector of output names.
#' @param samplingData A list with the sampling data from the method getSamplingData.
#' @param unitXAxis A list with the unit of the x-axis.
#' @param unitYAxis A list with the unit of the y-axis.
#' @param designName Character string: design name.
#' @return A list with the plot of the evaluation of gradient of the model responses.
#' @export
# ==============================================================================

method( plotEvaluationSI, Arm ) = function( arm, evaluationModelGradient, parametersNames, outputNames, samplingData, designName, plotOptions ) {

  unitXAxis = .normalizePlotOptions( plotOptions, outputNames )$unitTime
  armName = prop(arm, "name")
  plotList = list()
  plotList[[designName]] = list()
  plotList[[designName]][[armName]] = list()

  plots = map2(outputNames, samplingData$samplings, function(outputName, sampling) {

    gradientData = evaluationModelGradient[[outputName]]

    minYAxis = min(gradientData[, parametersNames], na.rm = TRUE)
    maxYAxis = max(gradientData[, parametersNames], na.rm = TRUE)

    map(parametersNames, function(parameterName) {

      data = as_tibble(gradientData[, c("time", parameterName)])
      names(data)[2] = "parameterValue"

      samplingPoints = data[data$time %in% sampling, ]

      ggplot(data, aes(x = time, y = parameterValue)) +
        geom_line() +
        geom_point(data = samplingPoints, color = "red") +
        labs( y = paste0("df/d", parameterName),
              x = paste0(
                "Time (", unitXAxis, ")\n\n",
                "Design: ", gsub("_", " ", designName), "   ",
                "Arm: ", armName, "   ",
                "Output: ", outputName, "   ",
                "Parameter: ", parameterName ) ) +
        scale_x_continuous( breaks = pretty_breaks(n = 10),
                            sec.axis = sec_axis(~., breaks = round(sampling, 2), name = "Sampling times") ) +
        scale_y_continuous( breaks = pretty_breaks(n = 10),
                            limits = c(minYAxis, maxYAxis) ) +
        theme( legend.position = "none",
               axis.title.x.top = element_text(color = "red", vjust = 2.0),
               axis.text.x.top = element_text(angle = 90, hjust = 0, color = "red"),
               plot.title = element_text(size = 16, hjust = 0.5),
               axis.title.x = element_text(size = 16),
               axis.title.y = element_text(size = 16),
               axis.text.x = element_text(size = 16, angle = 90, vjust = 0.5),
               axis.text.y = element_text(size = 16),
               strip.text.x = element_text(size = 16)
        )
    })
  })
  plotList[[designName]][[armName]] = map2(outputNames, plots, ~ setNames(.y, parametersNames)) |> set_names(outputNames)
  return( plotList )
}
