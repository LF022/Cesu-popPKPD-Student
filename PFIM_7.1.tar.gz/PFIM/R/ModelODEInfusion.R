#' @title ModelODEInfusion
#' @description ODE model with infusion inputs.
#' @inheritParams ModelInfusion
#' @include ModelInfusion.R
#' @export

ModelODEInfusion = new_class( "ModelODEInfusion", package = "PFIM", parent = ModelInfusion )

# ==============================================================================
#' evaluateInitialConditions: evaluate the initial conditions.
#' @name evaluateInitialConditions
#' @param model A \code{ModelODEInfusion} object.
#' @param arm An \code{Arm} object.
#' @return A named numeric vector of evaluated initial conditions.
#' @export
# ==============================================================================

# Delegates to the shared implementation defined in ModelODE.R.
# ModelODEInfusion does not inherit from ModelODE (it inherits from ModelInfusion),
# so the method must be registered explicitly here.
method( evaluateInitialConditions, ModelODEInfusion ) = function( model, arm ) {
  .evalInitialConditionsImpl( model, arm )
}
