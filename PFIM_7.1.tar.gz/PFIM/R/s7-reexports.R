#' Re-export S7 property accessor for PFIM objects
#'
#' PFIM objects are S7 classes; use \code{prop()} to read or set slots
#' (e.g. \code{prop(evaluation, "fim")}).
#'
#' @param object An S7 object (e.g. \code{Evaluation}, \code{Arm}).
#' @param name   Property name (character scalar).
#' @return Property value; use \code{prop(x, "name") <- value} to assign.
#' @name prop
#' @export
prop = S7::prop
