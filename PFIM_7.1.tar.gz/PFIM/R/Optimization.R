#' @title Optimization
#' @description
#' Design optimization: search over sampling times (or related design variables)
#' using a metaheuristic or exchange algorithm. Holds a \code{PFIMProject} in the
#' \code{project} slot (composition) plus optimization results.
#' @inheritParams PFIMProject
#' @param project Nested \code{PFIMProject} (filled by the constructor).
#' @param optimisationDesign List with initial and optimal design evaluations.
#' @param optimisationAlgorithmOutputs Raw outputs from the optimization algorithm.
#' @include PFIMProject.R
#' @include pfim-project-access.R
#' @export

Optimization = new_class( "Optimization",
                          package    = "PFIM",
                          properties = list(
                            project                      = new_property( PFIMProject ),
                            optimisationDesign           = new_property( class_list, default = list() ),
                            optimisationAlgorithmOutputs = new_property( class_list, default = list() )
                          ),
                          constructor = function(
                              name = character(0),
                              modelEquations = list(),
                              modelCovariatesEquation = character(0),
                              modelFromLibrary = list(),
                              modelParameters = list(),
                              modelCovariates = list(),
                              modelError = list(),
                              optimizer = character(0),
                              optimizerParameters = list(),
                              outputs = list(),
                              designs = list(),
                              fimType = character(0),
                              fim = NULL,
                              odeSolverParameters = list(),
                              project = NULL,
                              optimisationDesign = list(),
                              optimisationAlgorithmOutputs = list() ) {
                            if ( is.null( project ) ) {
                              if ( is.null( fim ) )
                                fim = .placeholderFim( fimType )
                              project = PFIMProject(
                                name = name,
                                modelEquations = modelEquations,
                                modelCovariatesEquation = modelCovariatesEquation,
                                modelFromLibrary = modelFromLibrary,
                                modelParameters = modelParameters,
                                modelCovariates = modelCovariates,
                                modelError = modelError,
                                optimizer = optimizer,
                                optimizerParameters = optimizerParameters,
                                outputs = outputs,
                                designs = designs,
                                fimType = fimType,
                                fim = fim,
                                odeSolverParameters = odeSolverParameters
                              )
                            }
                            new_object(
                              .parent                      = S7_object(),
                              project                      = project,
                              optimisationDesign           = optimisationDesign,
                              optimisationAlgorithmOutputs = optimisationAlgorithmOutputs
                            )
                          }
)
S4_register( Optimization )

method( defineFim, Optimization ) = function( pfimproject ) {
  defineFim( projectOf( pfimproject ) )
}

method( defineModelEquationsFromLibraryOfModel, Optimization ) = function( pfimproject ) {
  res = defineModelEquationsFromLibraryOfModel( projectOf( pfimproject ) )
  projectProp( pfimproject, "modelEquations" ) = res
  res
}

method( defineModelType, Optimization ) = function( pfimproject ) {
  defineModelType( projectOf( pfimproject ) )
}

defineOptimizationAlgorithm  = new_generic( "defineOptimizationAlgorithm", c( "optimization" ) )
generateFimsFromConstraints  = new_generic( "generateFimsFromConstraints",  c( "optimization" ) )
plotWeights                  = new_generic( "plotWeights",                  c( "optimization" ) )
plotFrequencies              = new_generic( "plotFrequencies",              c( "optimization" ) )
optimizeDesign               = new_generic( "optimizeDesign",  c( "optimizationObject", "optimizationAlgorithm" ) )
constraintsTableForReport    = new_generic( "constraintsTableForReport",    c( "optimizationAlgorithm" ) )

.getOptimalEval = function( optimization ) {
  prop( optimization, "optimisationDesign" )$evaluationOptimalDesign
}

.getOptimalFim = function( optimization ) {
  eval  = .getOptimalEval( optimization )
  fim   = prop( eval, "fim" )
  setEvaluationFim( fim, eval )
}

# ==============================================================================
#' defineOptimizationAlgorithm: instantiate the algorithm from the optimizer slot
#' @name defineOptimizationAlgorithm
#' @param optimization An \code{Optimization} object.
#' @return An optimization algorithm object.
#' @export
# ==============================================================================

method( defineOptimizationAlgorithm, Optimization ) = function( optimization ) {
  optimizerParameters = projectProp( optimization, "optimizer" )

  switch( optimizerParameters,
          MultiplicativeAlgorithm = MultiplicativeAlgorithm(),
          FedorovWynnAlgorithm    = FedorovWynnAlgorithm(),
          PSOAlgorithm            = PSOAlgorithm(),
          PGBOAlgorithm           = PGBOAlgorithm(),
          SimplexAlgorithm        = SimplexAlgorithm(),
          stop( sprintf( "Unknown optimizer: '%s'", optimizerParameters ) )
  )
}

# ==============================================================================
#' run: run the optimization
#' @name run
#' @param optimization An \code{Optimization} object.
#' @return The optimization design results.
#' @export
# ==============================================================================

method( run, Optimization ) = function( pfimproject ) {
  .invalidateEvalModelCache( pfimproject )
  optimizationAlgorithm = defineOptimizationAlgorithm( pfimproject )
  projectProp( pfimproject, "fim" ) = defineFim( pfimproject )

  if ( length( projectProp( pfimproject, "modelFromLibrary" ) ) != 0L )
    projectProp( pfimproject, "modelEquations" ) =
      defineModelEquationsFromLibraryOfModel( pfimproject )

  optimizeDesign( pfimproject, optimizationAlgorithm )
}

# ==============================================================================

method( show, Optimization ) = function( object ) {

  optimisationDesign      = prop( object, "optimisationDesign" )
  evaluationInitialDesign = optimisationDesign$evaluationInitialDesign
  evaluationOptimalDesign = optimisationDesign$evaluationOptimalDesign

  # Helper: extract arm data as a formatted data frame
  .armTable = function( evaluation ) {
    designs  = prop( evaluation, "designs" )
    armsData = list_flatten( map( pluck( map( designs, ~ prop( .x, "arms" ) ), 1L ),
                                  getArmData ) )
    df = map( armsData, ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |> list_rbind()
    colnames( df ) = c( "Arms name", "Number of subjects", "Outcome", "Dose", "Sampling times" )
    df
  }

  fimInitialDesign = setEvaluationFim( prop( evaluationInitialDesign, "fim" ), evaluationInitialDesign )
  fimOptimalDesign = setEvaluationFim( prop( evaluationOptimalDesign, "fim" ), evaluationOptimalDesign )

  cat( "\n===================================== \n" )
  cat( "  Initial design \n" )
  cat( "===================================== \n\n" )
  print( .armTable( evaluationInitialDesign ) )
  showFIM( fimInitialDesign )

  cat( "\n===================================== \n" )
  cat( "  Optimal design \n" )
  cat( "===================================== \n\n" )
  print( .armTable( evaluationOptimalDesign ) )
  showFIM( fimOptimalDesign )

  invisible( object )
}

# ==============================================================================
#' getFisherMatrix: return the three FIM components for the optimal design
#' @name getFisherMatrix
#' @param pfimproject An \code{Optimization} object.
#' @return List with fisherMatrix, fixedEffects, varianceEffects.
#' @export
# ==============================================================================

method( getFisherMatrix, Optimization ) = function( pfimproject ) {
  fim = .getOptimalFim( pfimproject )
  list(
    fisherMatrix    = prop( fim, "fisherMatrix"    ),
    fixedEffects    = prop( fim, "fixedEffects"    ),
    varianceEffects = prop( fim, "varianceEffects" )
  )
}

# ==============================================================================
#' getSE: return the SE data frame for the optimal design
#' @name getSE
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( getSE, Optimization ) = function( pfimproject ) {
  prop( .getOptimalFim( pfimproject ), "SEAndRSE" )$SE
}

# ==============================================================================
#' getRSE: return the RSE data frame for the optimal design
#' @name getRSE
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( getRSE, Optimization ) = function( pfimproject ) {
  prop( .getOptimalFim( pfimproject ), "SEAndRSE" )$RSE
}

# ==============================================================================
#' getShrinkage: return the shrinkage of the FIM
#' @name getShrinkage
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( getShrinkage, Optimization ) = function( pfimproject ) {
  prop( .getOptimalFim( pfimproject ), "shrinkage" )
}

# ==============================================================================
#' getDeterminant: return the determinant of the FIM
#' @name getDeterminant
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( getDeterminant, Optimization ) = function( pfimproject ) {
  det( prop( .getOptimalFim( pfimproject ), "fisherMatrix" ) )
}

# ==============================================================================
#' getCorrelationMatrix: return the correlation matrix of the FIM
#' @name getCorrelationMatrix
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( getCorrelationMatrix, Optimization ) = function( pfimproject ) {
  cor( prop( .getOptimalFim( pfimproject ), "fisherMatrix" ) )
}

# ==============================================================================
#' getDcriterion: return the D-criterion of the FIM
#' @name getDcriterion
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( getDcriterion, Optimization ) = function( pfimproject ) {
  Dcriterion( .getOptimalFim( pfimproject ) )
}

# ==============================================================================
#' plotSensitivityIndices: plot sensitivity indices for the optimal design
#' @name plotSensitivityIndices
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( plotSensitivityIndices, Optimization ) = function( pfimproject ) {
  plotSensitivityIndices( .getOptimalEval( pfimproject ) )
}

# ==============================================================================
#' plotSE: barplot of SE for the optimal design
#' @name plotSE
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( plotSE, Optimization ) = function( pfimproject ) {
  plotSEFIM( .getOptimalFim( pfimproject ), .getOptimalEval( pfimproject ) )
}

# ==============================================================================
#' plotRSE: barplot of RSE for the optimal design
#' @name plotRSE
#' @param pfimproject An \code{Optimization} object.
#' @export
# ==============================================================================

method( plotRSE, Optimization ) = function( pfimproject ) {
  plotRSEFIM( .getOptimalFim( pfimproject ), .getOptimalEval( pfimproject ) )
}

# ==============================================================================
#' plotWeights: plot algorithm weights (MultiplicativeAlgorithm)
#' @name plotWeights
#' @param optimization An \code{Optimization} object.
#' @export
# ==============================================================================

method( plotWeights, Optimization ) = function( optimization ) {
  plotWeightsMultiplicativeAlgorithm(
    optimization,
    prop( optimization, "optimisationAlgorithmOutputs" )$optimizationAlgorithm
  )
}

# ==============================================================================
#' plotFrequencies: plot optimal frequencies (FedorovWynnAlgorithm)
#' @name plotFrequencies
#' @param optimization An \code{Optimization} object.
#' @export
# ==============================================================================

method( plotFrequencies, Optimization ) = function( optimization ) {
  plotFrequenciesFedorovWynnAlgorithm(
    optimization,
    prop( optimization, "optimisationAlgorithmOutputs" )$optimizationAlgorithm
  )
}
