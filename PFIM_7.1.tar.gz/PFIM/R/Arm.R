#' @title Arm
#' @description
#' One experimental arm: subjects, dosing, sampling times, and slots filled during
#' design evaluation (model predictions, gradients, variance, FIM).
#' @param name Character string: arm identifier.
#' @param size Numeric: number of subjects in the arm.
#' @param administrations List of \code{Administration} objects.
#' @param initialConditions List of ODE initial conditions (name = variable, value = numeric).
#' @param samplingTimes List of \code{SamplingTimes} objects.
#' @param administrationsConstraints List of \code{AdministrationConstraints} objects.
#' @param samplingTimesConstraints List of \code{SamplingTimeConstraints} objects.
#' @param evaluationModel Model predictions at sampling times (filled by \code{evaluateArm}).
#' @param evaluationGradients Gradients of responses w.r.t. parameters (nested if covariates/IOV).
#' @param evaluationVariance Residual variance structure for the arm.
#' @param evaluationFim FIM object after \code{evaluateFim}.
#' @param covariateSampling Optional \code{CovariateSamplingMethods} object.
#' @include Model.R
#' @include Fim.R
#' @include MultiplicativeAlgorithm.R
#' @include FedorovWynnAlgorithm.R
#' @include SimplexAlgorithm.R
#' @include PSOAlgorithm.R
#' @include PGBOAlgorithm.R
#' @include CovariateSamplingMethods.R
#' @export

Arm = new_class("Arm", package = "PFIM",

                properties = list(
                  name = new_property(class_character, default = character(0)),
                  size = new_property(class_double, default = numeric(0)),
                  administrations = new_property(class_list, default = list()),
                  initialConditions = new_property(class_list, default = list()),
                  samplingTimes = new_property(class_list, default = list()),
                  administrationsConstraints = new_property(class_list, default = list()),
                  samplingTimesConstraints = new_property(class_list, default = list()),
                  evaluationModel = new_property(class_list, default = list()),
                  evaluationGradients = new_property(class_list, default = list()),
                  evaluationVariance = new_property(class_list, default = list()),
                  evaluationFim = new_property(Fim, default = NULL),
                  covariateSampling = new_property(CovariateSamplingMethods, default = NULL)
                ))



evaluateArm = new_generic( "evaluateArm", c( "arm" ) )
getSamplingData = new_generic( "getSamplingData", c( "arm" ) )
updateSamplingTimes = new_generic( "updateSamplingTimes", c( "arm" ) )
processArmEvaluationResults = new_generic( "processArmEvaluationResults", c( "arm", "model", "fim" ) )
processArmEvaluationSI = new_generic( "processArmEvaluationSI", c( "arm", "model", "fim" ) )
plotEvaluationResults = new_generic( "plotEvaluationResults", c( "arm" ) )
plotEvaluationSI = new_generic( "plotEvaluationSI", c( "arm" ) )

getArmData = new_generic( "getArmData", c( "arm" ) )
getArmConstraints = new_generic( "getArmConstraints", c( "arm", "optimizationAlgorithm" ) )
armAdministration = new_generic( "armAdministration", c( "arm" ) )

# ==============================================================================
#' Evaluate model, gradients, variance, and FIM for one arm.
#'
#' @name evaluateArm
#' @param arm An \code{Arm} object.
#' @param model A \code{Model} object (with covariate data defined when required).
#' @param fim A \code{Fim} object (\code{PopulationFim} required for covariates/IOV).
#' @return The \code{Arm} with \code{evaluationModel}, \code{evaluationGradients},
#'   \code{evaluationVariance}, and \code{evaluationFim} populated.
#' @export
# ==============================================================================

method( evaluateArm, Arm ) = function( arm, model, fim ) {

  model = .pfimPrepareModelForEvaluation( model, arm )

  prop( arm, "evaluationModel" ) <- evaluateModel( model, arm )
  prop( arm, "evaluationGradients" ) <- evaluateModelGradient( model, arm )
  prop( arm, "evaluationVariance" ) <- evaluateModelVariance( model, arm )

  armFim = .duplicateFim( fim )
  prop( arm, "evaluationFim" ) <- evaluateFim( armFim, model, arm )

  return( arm )
}
