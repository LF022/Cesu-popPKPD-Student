# ==============================================================================
#' getFisherMatrix: Display the Fisher Information Matrix components
#'
#' @description
#' Extracts and returns the partitioned components of the Fisher Information Matrix (FIM),
#' including the full matrix, fixed effects, and variance effects.
#'
#' @name getFisherMatrix
#' @param evaluation An object of class \code{Evaluation} containing the results of a design evaluation.
#' @return A \code{list} containing:
#' \itemize{
#'   \item \code{fisherMatrix}: The full Fisher Information Matrix.
#'   \item \code{fixedEffects}: The sub-matrix corresponding to fixed effects.
#'   \item \code{varianceEffects}: The sub-matrix corresponding to variance components (random effects).
#' }
#'
#' @examples
#' \dontrun{
#' # Assuming 'evaluationResults' is an object returned by the run() function
#' fimComponents = getFisherMatrix(evaluationResults)
#'
#' # Access the specific matrices
#' fullFim = fimComponents$fisherMatrix
#' fixedEff = fimComponents$fixedEffects
#' }
#' @export
# ==============================================================================

method( getFisherMatrix, Evaluation ) = function( pfimproject )
{
  fim = prop( pfimproject, "fim" )
  fim = setEvaluationFim( fim, pfimproject )
  fisherMatrix = prop( fim, "fisherMatrix" )
  fixedEffects = prop( fim, "fixedEffects" )
  varianceEffects = prop( fim, "varianceEffects" )

  return( list( fisherMatrix = fisherMatrix, fixedEffects = fixedEffects, varianceEffects = varianceEffects ) )
}

# ==============================================================================

method( show, Evaluation ) = function( object )
{
  fim = setEvaluationFim( prop( object, "fim" ), object )
  prop( object, "fim" ) <- fim
  .showPopulationFimConsole( fim, object )
}

# ==============================================================================
#' plotEvaluation: Plot model responses for design evaluation
#'
#' @description
#' Generates graphical representations of the model responses based on the
#' design and parameters defined in the PFIM project.
#'
#' @name plotEvaluation
#' @param pfimproject An object of class \code{PFIMProject} containing the design.
#' @param plotOptions A \code{list} specifying graphical parameters (e.g., \code{xlim}, \code{ylim}, \code{main}, \code{col}).
#' @return A series of plots representing the expected model responses and sampling schedules.
#'
#' @examples
#' \dontrun{
#' # 1. Define custom plot options, e.g. form the Vignette 01:
#' myPlotOptions = list( unitTime = c( "hour" ), unitOutcomes= c( "mcg/mL" , "DI%" ) )
#'
#' # 2. Generate the plots for the project
#' plotEvaluation(myPFIMproject, plotOptions = myPlotOptions)
#' }
#' @export
# ==============================================================================


method( getSE, Evaluation ) = function( pfimproject )
{
  # set the FIM and plot SE
  fim = prop( pfimproject, "fim" )
  fim = setEvaluationFim( fim, pfimproject )
  SEAndRSE = prop( fim, "SEAndRSE" )
  SE = SEAndRSE$SE
  return( SE )
}

# ==============================================================================
#' Relative standard errors from the evaluated FIM.
#'
#' @name getRSE
#' @param pfimproject An \code{Evaluation} object after \code{run()}.
#' @return Data frame of RSE values.
#' @export
# ==============================================================================

method( getRSE, Evaluation ) = function( pfimproject )
{
  # set the FIM and plot SE
  fim = prop( pfimproject, "fim" )
  fim = setEvaluationFim( fim, pfimproject )
  SEAndRSE = prop( fim, "SEAndRSE" )
  RSE = SEAndRSE$RSE
  return( RSE )
}

# ==============================================================================
#' Bayesian shrinkage values (Bayesian FIM only).
#'
#' @name getShrinkage
#' @param pfimproject An \code{Evaluation} object after \code{run()}.
#' @return Named numeric vector of shrinkage (percent).
#' @export
# ==============================================================================

method( getShrinkage, Evaluation ) = function( pfimproject )
{
  # set the FIM and plot SE
  fim = prop( pfimproject, "fim" )
  fim = setEvaluationFim( fim, pfimproject )
  shrinkage = prop( fim, "shrinkage" )
  return( shrinkage )
}

# ==============================================================================
#' Determinant of the Fisher information matrix (D-criterion).
#'
#' @name getDeterminant
#' @param pfimproject An \code{Evaluation} object after \code{run()}.
#' @return Numeric determinant.
#' @export
# ==============================================================================

method( getDeterminant, Evaluation ) = function( pfimproject )
{
  fisherMatrix = getFisherMatrix( pfimproject )
  return( det( fisherMatrix$fisherMatrix ) )
}

# ==============================================================================
#' D-criterion value from the evaluated FIM.
#'
#' @name getDcriterion
#' @param pfimproject An \code{Evaluation} object after \code{run()}.
#' @return Numeric D-criterion.
#' @export
# ==============================================================================

method( getDcriterion, Evaluation ) = function( pfimproject )
{
  fim = prop( pfimproject, "fim" )
  fim = setEvaluationFim( fim, pfimproject )
  return( Dcriterion( fim ) )
}

# ==============================================================================
#' getCorrelationMatrix: parameter correlation matrix derived from the FIM.
#'
#' Returns \eqn{R = D^{-1/2} C D^{-1/2}} where \eqn{C = M^{-1}} is the
#' CramÃ©r-Rao covariance bound and \eqn{D = \mathrm{diag}(C)}.
#'
#' @name getCorrelationMatrix
#' @param pfimproject A \code{PFIMProject} object (\code{Evaluation} after \code{run()}).
#' @return A symmetric named matrix of correlations between parameter estimates,
#'   derived from the inverse of the Fisher information matrix.
#' @export
# ==============================================================================

method( getCorrelationMatrix, Evaluation ) = function( pfimproject )
{
  fim       = setEvaluationFim( prop( pfimproject, "fim" ), pfimproject )
  M         = prop( fim, "fisherMatrix" )
  covMatrix = .safeCholInv( M )   # Cramer-Rao covariance = M^{-1}
  cov2cor( covMatrix )                # normalise to correlation matrix
}
