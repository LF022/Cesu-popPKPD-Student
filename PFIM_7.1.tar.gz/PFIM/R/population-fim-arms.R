# â”€â”€ setOptimalArms â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# Population FIM allocates actual N individuals (proportional), unlike
# IndividualFim/BayesianFim which use unit weights.

#' @name setOptimalArms
#' @export
method( setOptimalArms, list( PopulationFim, MultiplicativeAlgorithm ) ) =
  function( fim, optimizationAlgorithm ) {

    outputs      = prop( optimizationAlgorithm, "multiplicativeAlgorithmOutputs" )
    weightsIndex = outputs$weightsIndex
    weights      = outputs$optimalWeights
    N_total      = prop( outputs$armFims[[ weightsIndex[ 1L ] ]][[ 1L ]], "size" )
    nPerGroup    = round( N_total * weights / sum( weights ) )

    armList = map2( weightsIndex, nPerGroup, function( idx, size ) {
      arm = outputs$armFims[[ idx ]][[ 1L ]]
      prop( arm, "size" ) <- size
      prop( arm, "name" ) <- paste0( "Arm", idx )
      arm
    })
    armList[ order( map_dbl( armList, ~ prop( .x, "size" ) ), decreasing = TRUE ) ]
  }

#' @name setOptimalArms
#' @export
method( setOptimalArms, list( PopulationFim, FedorovWynnAlgorithm ) ) =
  function( fim, optimizationAlgorithm ) {
    outputs             = prop( optimizationAlgorithm, "FedorovWynnAlgorithmOutputs" )
    numberOfIndividuals = outputs$numberOfIndividuals
    map2( outputs$listArms, seq_along( outputs$listArms ), function( la, i ) {
      prop( la$arm, "size" ) <- as.double( numberOfIndividuals[[ i ]] )
      prop( la$arm, "name" ) <- paste0( "Arm", i )
      la
    })
  }
