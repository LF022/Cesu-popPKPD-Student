#' @title PopulationFim
#' @description
#' Population Fisher information matrix for nonlinear mixed-effects models.
#'
#' **Required** when the model has covariates, occasion covariates, or multiple
#' occasions (IOV). Supports the combination-by-occasion gradient and variance
#' structure via \code{usesCovariateOccasionStructure(model)}.
#'
#' @inheritParams Fim
#' @details
#' The population FIM has fixed-effects (\eqn{\mu}, \eqn{\beta}) and variance-effects
#' (\eqn{\omega^2}, \eqn{\gamma^2}, \eqn{\sigma}) blocks:
#' \deqn{M_P = \mathrm{bdiag}(N \cdot M_\mu,\; N \cdot M_\lambda)}
#' where \eqn{N} is the arm size and \eqn{M_\mu = G_\mu^\top V^{-1} G_\mu}.
#' @include Fim.R
#' @export

PopulationFim = new_class( "PopulationFim", package = "PFIM", parent = Fim )
S4_register( PopulationFim )

# NOTE: .GREEK_CONSOLE, .GREEK_PLOT, .GREEK_LATEX are defined in Fim.R
# (the common ancestor of all FIM classes).  They are available here via
# the @include chain without redefining them.

# ==============================================================================
#' evaluateFim — PopulationFim
#' @name evaluateFim
#' @param fim   A \code{PopulationFim} object.
#' @param model A \code{Model} object.
#' @param arm   An \code{Arm} object.
#' @return The updated \code{PopulationFim} with \code{fisherMatrix} set.
#' @export
# ==============================================================================

method( evaluateFim, list( PopulationFim, Model, Arm ) ) = function( fim, model, arm ) {

  parameters          = prop( model, "modelParameters" )
  armSize             = prop( arm,   "size"            )
  hasComplexStructure = usesCovariateOccasionStructure( model )

  isFixedMu    = map_lgl( parameters, ~ isTRUE( prop( .x, "fixedMu"    ) ) ||
                            prop( prop( .x, "distribution" ), "mu"    ) == 0 )
  isFixedOmega = map_lgl( parameters, ~ isTRUE( prop( .x, "fixedOmega" ) ) ||
                            prop( prop( .x, "distribution" ), "omega" ) == 0 )

  result = .evaluateVarianceFIMPop( fim, model, arm,
                                    isFixedMu    = isFixedMu,
                                    isFixedOmega = isFixedOmega )

  if ( !hasComplexStructure ) {
    nSigma     = ncol( result$MFVar ) - length( isFixedOmega )
    keepLambda = c( !isFixedOmega, rep( TRUE, nSigma ) )
    MFVar      = result$MFVar[ keepLambda, keepLambda, drop = FALSE ]
  } else {
    MFVar = result$MFVar
  }

  prop( fim, "fisherMatrix" ) <- as.matrix(
    bdiag( result$MFbeta * armSize, MFVar * armSize )
  )
  fim
}
