# â”€â”€ Shared bar chart backbone â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
.plotFimBars = function( fim, evaluation, metric ) {
  parameters = prop( evaluation, "modelParameters" )
  modelError = prop( evaluation, "modelError"       )
  fim        = setEvaluationFim( prop( evaluation, "fim" ), evaluation )
  se         = prop( fim, "SEAndRSE" )
  greek      = .GREEK_PLOT   # defined in Fim.R
  has_IOV    = any( map_dbl( parameters, ~ pluck( .x, "gamma", .default = 0 ) ) > 0 )

  paramsMu    = parameters |>
    keep( ~ !isTRUE( prop( .x, "fixedMu" ) ) &&
            prop( prop( .x, "distribution" ), "mu" ) != 0 ) |>
    map_chr( ~ prop( .x, "name" ) )
  paramsOmega = parameters |>
    keep( ~ !isTRUE( prop( .x, "fixedOmega" ) ) &&
            prop( prop( .x, "distribution" ), "omega" ) != 0 ) |>
    map_chr( ~ prop( .x, "name" ) )
  paramsGamma = if ( has_IOV )
    parameters |>
    keep( ~ pluck( .x, "gamma", .default = 0 ) > 0 &&
            !isTRUE( prop( .x, "fixedOmega" ) ) ) |>
    map_chr( ~ prop( .x, "name" ) )
  else character( 0L )
  paramsSigma = .sigmaNames( modelError, greek[ "sigma" ] )

  y_vals = if ( metric == "SE" ) se$SE$SE else se$RSE$RSE
  cats   = paste0( metric, " ", c(
    rep( greek[ "mu"    ], length( paramsMu    ) ),
    rep( greek[ "omega" ], length( paramsOmega ) ),
    rep( greek[ "gamma" ], length( paramsGamma ) ),
    rep( greek[ "sigma" ], length( paramsSigma ) )
  ))

  df = data.frame( Parameter        = c( paramsMu, paramsOmega, paramsGamma, paramsSigma ),
                   parametersValues = se$SEAndRSE$parametersValues,
                   y                = y_vals,
                   cat              = cats )
  names( df )[ 3L ] = metric

  facet_levels = paste0( metric, " ", c( greek[ "mu" ], greek[ "omega" ],
                                         if ( has_IOV ) greek[ "gamma" ],
                                         greek[ "sigma" ] ) )

  ggplot( df, aes( x = .data[["Parameter"]], y = .data[[ metric ]] ) ) +
    geom_bar( stat = "identity", show.legend = FALSE ) +
    facet_wrap( ~ factor( cat, levels = facet_levels ), scales = "free_x" ) +
    theme( legend.position = "none",
           plot.title  = element_text( size = 16, hjust = 0.5 ),
           axis.title  = element_text( size = 16 ),
           axis.text.x = element_text( size = 16, angle = 90, vjust = 0.5 ),
           axis.text.y = element_text( size = 16 ),
           strip.text.x = element_text( size = 16 ) )
}

# ==============================================================================
#' setEvaluationFim — PopulationFim
#' @name setEvaluationFim
#' @export
# ==============================================================================

method( setEvaluationFim, PopulationFim ) = function( fim, evaluation ) {

  parameters      = prop( evaluation, "modelParameters" )
  modelError      = prop( evaluation, "modelError"       )
  modelCovariates = prop( evaluation, "modelCovariates"  )
  greek           = .GREEK_CONSOLE   # defined in Fim.R

  has_IOV = any( map_dbl( parameters, ~ pluck( .x, "gamma", .default = 0 ) ) > 0 )
  has_cov = length( modelCovariates ) > 0L

  # Column names
  columnNamesMu    = .muNames(    parameters, greek[ "mu"    ] )
  columnNamesBeta  = if ( has_cov ) .betaInternalNamesFromCovariates( modelCovariates ) else character( 0L )
  columnNamesOmega = .omegaNames( parameters, greek[ "omega" ] )
  columnNamesGamma = if ( has_IOV ) .gammaNames( parameters, greek[ "gamma" ] ) else character( 0L )
  columnNamesSigma = .sigmaNames( modelError, greek[ "sigma" ] )

  # Parameter values
  muValues = parameters |>
    keep( ~ !isTRUE( prop( .x, "fixedMu" ) ) &&
            prop( prop( .x, "distribution" ), "mu" ) != 0 ) |>
    map_dbl( ~ prop( prop( .x, "distribution" ), "mu" ) )

  betaValues = if ( has_cov && length( columnNamesBeta ) > 0L ) {
    dict = .betaDictFromCovariates( modelCovariates )
    map_dbl( columnNamesBeta, ~ if ( .x %in% names( dict ) ) dict[[ .x ]] else NA_real_ )
  } else numeric( 0L )

  omegaValues = parameters |>
    keep( ~ !isTRUE( prop( .x, "fixedOmega" ) ) &&
            prop( prop( .x, "distribution" ), "omega" ) != 0 ) |>
    map_dbl( ~ prop( prop( .x, "distribution" ), "omega" )^2 )

  gammaValues = if ( has_IOV )
    parameters |>
    keep( ~ pluck( .x, "gamma", .default = 0 ) > 0 &&
            !isTRUE( prop( .x, "fixedOmega" ) ) ) |>
    map_dbl( ~ pluck( .x, "gamma" )^2 )
  else numeric( 0L )

  sigmaValues = modelError |>
    map( function( err ) {
      v = list()
      if ( prop( err, "sigmaInter" ) != 0 && !prop( err, "sigmaInterFixed" ) )
        v$sigmaInter = prop( err, "sigmaInter" )
      if ( prop( err, "sigmaSlope"  ) != 0 && !prop( err, "sigmaSlopeFixed"  ) )
        v$sigmaSlope = prop( err, "sigmaSlope" )
      v
    }) |> unlist( use.names = FALSE )

  M        = prop( fim, "fisherMatrix" )
  allNames = c( columnNamesMu, columnNamesBeta,
                columnNamesOmega, columnNamesGamma, columnNamesSigma )

  if ( ncol( M ) != length( allNames ) )
    stop( sprintf(
      "setEvaluationFim: FIM dim %d \u2260 %d column names.\nNames: %s",
      ncol( M ), length( allNames ), paste( allNames, collapse = ", " )
    ))

  dimnames( M ) = list( allNames, allNames )
  feNames       = c( columnNamesMu, columnNamesBeta )
  veNames       = c( columnNamesOmega, columnNamesGamma, columnNamesSigma )
  fixedEffects  = M[ feNames, feNames, drop = FALSE ]
  varEffects    = M[ veNames, veNames, drop = FALSE ]

  pVals = c( muValues, betaValues, omegaValues, gammaValues, sigmaValues )
  SE    = sqrt( diag( .safeCholInv( M ) ) )
  RSE   = SE / abs( pVals ) * 100
  seDF  = data.frame( parametersValues = pVals, SE = SE, RSE = RSE,
                      row.names = allNames )

  prop( fim, "fisherMatrix"              ) <- M
  prop( fim, "fixedEffects"              ) <- fixedEffects
  prop( fim, "varianceEffects"           ) <- varEffects
  prop( fim, "condNumberFixedEffects"    ) <- .conditionNumber( fixedEffects )
  prop( fim, "condNumberVarianceEffects" ) <- .conditionNumber( varEffects   )
  prop( fim, "SEAndRSE" ) <- list(
    SE       = seDF[ , c( "parametersValues", "SE"  ) ],
    RSE      = seDF[ , c( "parametersValues", "RSE" ) ],
    table    = seDF,
    SEAndRSE = seDF
  )
  fim
}

# ==============================================================================
#' Console summary for population FIM (used by \code{showFIM} and \code{show(Evaluation)}).
#' @param fim A \code{PopulationFim} object.
#' @param evaluation Optional \code{Evaluation} passed to refresh the SE/RSE table.
#' @keywords internal
# ==============================================================================

.showPopulationFimConsole = function( fim, evaluation = NULL ) {

  .hdr = function( t ) { cat( "\n*************************************** \n" )
    cat( " ", t, "\n" )
    cat( "*************************************** \n\n" ) }

  .hdr( "Parameters estimation" )
  .printFimSeAndRse( fim, evaluation )

  cat( "\n********************************************* \n",
       " determinant, condition numbers and d-criterion \n",
       "*********************************************** \n\n" )
  cat( "determinant:",  det( prop( fim, "fisherMatrix" ) ), "\n" )
  cat( "D-criterion:",  Dcriterion( fim ),                  "\n" )
  cat( "Conditional number (fixed effects):",      prop( fim, "condNumberFixedEffects"    ), "\n" )
  cat( "Conditional number (variance components):", prop( fim, "condNumberVarianceEffects"), "\n" )

  .hdr( "Population Fisher Matrix" );                     print( prop( fim, "fisherMatrix"   ) )
  .hdr( "Fixed effects (\u03bc)" );                       print( prop( fim, "fixedEffects"   ) )
  .hdr( "Variance components (\u03c9\u00B2, \u03b3\u00B2, \u03c3\u00B2)" )
  print( prop( fim, "varianceEffects" ) )

  if ( any( grepl( "\u03b3\u00B2", rownames( prop( fim, "fisherMatrix" ) ) ) ) ) {
    cat( "\n*************************************** \n Legend: \n" )
    cat( " \u03bc  = fixed effects (population means)\n" )
    cat( " \u03c9\u00B2 = inter-individual variability (IIV)\n" )
    cat( " \u03b3\u00B2 = inter-occasion variability (IOV)\n" )
    cat( " \u03c3\u00B2 = residual error variance\n" )
    cat( "*************************************** \n\n" )
  }

  invisible( fim )
}

# ==============================================================================
#' showFIM — PopulationFim
#' @name showFIM
#' @export
# ==============================================================================

method( showFIM, PopulationFim ) = function( fim ) {
  .showPopulationFimConsole( fim, evaluation = NULL )
}

#' @name plotSEFIM
#' @export
method( plotSEFIM,  list( PopulationFim, PFIMProject ) ) =
  function( fim, evaluation ) .plotFimBars( fim, evaluation, "SE"  )

#' @name plotRSEFIM
#' @export
method( plotRSEFIM, list( PopulationFim, PFIMProject ) ) =
  function( fim, evaluation ) .plotFimBars( fim, evaluation, "RSE" )
