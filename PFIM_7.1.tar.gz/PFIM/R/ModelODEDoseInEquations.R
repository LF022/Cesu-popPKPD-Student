#' @title ModelODEDoseInEquations
#' @description ODE model with dose terms inside the differential equations.
#' @inheritParams ModelODE
#' @param modelODEDoseInEquations A function: the compiled ODE solver function.
#' @param solverInputs            A list: per-outcome administration schedules.
#' @include Model.R
#' @include ModelODE.R
#' @export

ModelODEDoseInEquations = new_class( "ModelODEDoseInEquations",
                                     package = "PFIM",
                                     parent  = ModelODE,
                                     properties = list(
                                       modelODEDoseInEquations = new_property(class_function, default = NULL),
                                       solverInputs            = new_property(class_list,     default = list())
                                     ))

# ==============================================================================
#' defineModelWrapper: build the ODE wrapper for the dose-in-equations model.
#' @name defineModelWrapper
#' @param model      A \code{ModelODEDoseInEquations} object.
#' @param evaluation An \code{Evaluation} object.
#' @return The model with updated properties.
# ==============================================================================

method( defineModelWrapper, ModelODEDoseInEquations ) = function( model, evaluation ) {

  equations                  = prop( evaluation, "modelEquations" )
  variableNames              = str_remove( names( equations ), "Deriv_" )
  outcomesWithAdministration = .getOutcomesFromEvaluation( evaluation )
  parameterNames             = map_chr( prop( evaluation, "modelParameters" ), "name" )
  doseNames                  = paste0( "dose_", outcomesWithAdministration )
  timeNames                  = paste0( "t_",    outcomesWithAdministration )
  functionArguments          = unique( c( doseNames, parameterNames, variableNames, timeNames ) )
  functionArgumentsSymbols   = map( functionArguments, as.symbol )

  # Replace bare "t" with "t_<outcome>" in equations that reference the
  # corresponding dose variable (the ODE solver time is re-based per dose interval).
  equations = map( equations, \( eq ) {
    reduce( seq_along( outcomesWithAdministration ), \( e, i ) {
      outcome = outcomesWithAdministration[i]
      if ( str_detect( e, paste0( "dose_", outcome ) ) )
        str_replace_all( e, "\\bt\\b", paste0( "t_", outcome ) )
      else
        e
    }, .init = eq )
  })

  outputs = prop( evaluation, "outputs" )
  prop( model, "outputFormula" ) <- outputs
  prop( model, "outputNames" ) <- names( outputs )
  prop( model, "outcomesWithAdministration" ) <- outcomesWithAdministration
  prop( model, "wrapper" ) <- .buildODEWrapper( equations, functionArguments )
  prop( model, "functionArguments" ) <- functionArguments
  prop( model, "functionArgumentsSymbol" ) <- functionArgumentsSymbols

  return( model )
}

# ==============================================================================
# Internal administration builders (shared with gradient performance cache).
# ==============================================================================

#' @keywords internal
.odeDoseInEqSolverInputsFromArm = function( arm, samplings ) {
  administrations = prop( arm, "administrations" )
  map( administrations, function( adm ) {
    outcome  = prop( adm, "outcome" )
    tau      = prop( adm, "tau" )
    dosing   = .alignAdministrationDosing( adm )
    timeDose = dosing$timeDose
    dose     = dosing$dose

    administrationTime = if ( tau != 0 ) {
      tSeq = seq( 0, max( samplings ), tau )
      dose = rep( dose, length( tSeq ) )
      cbind( tSeq[ -length( tSeq ) ], tSeq[ -1 ] )
    } else if ( length( timeDose ) == 1L ) {
      matrix( rep( timeDose, 2 ), nrow = 1 )
    } else {
      cbind( timeDose, c( timeDose[ -1 ], max( samplings ) ) )
    }

    set_names( list( list( administrationTime = administrationTime, dose = dose ) ), outcome )
  } ) |> list_flatten()
}

#' @keywords internal
.odeDoseInEqFinalizeAdministration = function(
    model, mu, initialConditions, samplings, solverInputs,
    outcomesWithAdministration, wrapper, functionArguments,
    functionArgumentsSymbols, outputFormula ) {

  modelODEDoseInEquations = function( t, y, parms ) {
    doseTimeVars = list()
    for ( outcome in outcomesWithAdministration ) {
      adminTime = parms[[ outcome ]]$administrationTime
      idx       = which( t > adminTime[ , 1 ] & t <= adminTime[ , 2 ] )
      doseTimeVars[[ paste0( "dose_", outcome ) ]] =
        if ( length( idx ) > 0 ) parms[[ outcome ]]$dose[ idx ] else parms[[ outcome ]]$dose[ 1 ]
      doseTimeVars[[ paste0( "t_", outcome ) ]] =
        if ( length( idx ) > 0 ) t - adminTime[ idx, 1 ] else t
    }

    with( as.list( c( list( t = t ), as.list( y ), as.list( mu ), doseTimeVars ) ), {
      evaluationModel   = do.call( wrapper, set_names( functionArgumentsSymbols, functionArguments ) )
      evaluationOutputs = map( outputFormula, ~ eval( .x ) )
      return( c( evaluationModel, evaluationOutputs ) )
    } )
  }

  prop( model, "initialConditions" ) <- initialConditions
  prop( model, "samplings" ) <- samplings
  prop( model, "modelODEDoseInEquations" ) <- modelODEDoseInEquations
  prop( model, "solverInputs" ) <- solverInputs
  model
}

# ==============================================================================
#' defineModelAdministration: build solver inputs and ODE function.
#' @name defineModelAdministration
#' @param model A \code{ModelODEDoseInEquations} object.
#' @param arm   An \code{Arm} object.
#' @return The model with updated properties.
#' @export
# ==============================================================================

method( defineModelAdministration, ModelODEDoseInEquations ) = function( model, arm ) {

  wrapper                    = prop( model, "wrapper" )
  parameters                 = prop( model, "modelParameters" )
  samplingTimes              = prop( arm,   "samplingTimes" )
  functionArguments          = prop( model, "functionArguments" )
  functionArgumentsSymbols   = prop( model, "functionArgumentsSymbol" )
  outputFormula              = map( prop( model, "outputFormula" ), ~ parse( text = .x ) )
  outcomesWithAdministration = prop( model, "outcomesWithAdministration" )
  samplings                  = .buildSamplings( samplingTimes )
  mu                         = .extractMu( parameters )

  solverInputs = .odeDoseInEqSolverInputsFromArm( arm, samplings )
  initialConditions = evaluateInitialConditions( model, arm )

  .odeDoseInEqFinalizeAdministration(
    model, mu, initialConditions, samplings, solverInputs,
    outcomesWithAdministration, wrapper, functionArguments,
    functionArgumentsSymbols, outputFormula
  )
}

# ==============================================================================
#' evaluateModel: solve the dose-in-equations ODE model.
#' @name evaluateModel
#' @param model A \code{ModelODEDoseInEquations} object.
#' @param arm   An \code{Arm} object.
#' @return A named list of data frames, one per output.
#' @export
# ==============================================================================

method( evaluateModel, ModelODEDoseInEquations ) = function( model, arm ) {

  evaluateCore = function( model, arm ) {
    odeSolverParameters = prop( model, "odeSolverParameters" )
    outputNames         = prop( model, "outputNames" )
    samplingTimes       = prop( arm,   "samplingTimes" )

    raw_samplings = prop( model, "samplings" )
    sim_key       = paste( "doseInEq", paste( raw_samplings, collapse = "," ), sep = "::" )
    sim_times     = .pfimOdeSimTimesCached( sim_key, raw_samplings, NULL )

    evaluationModelTmp = ode(
      prop( model, "initialConditions" ),
      sim_times,
      prop( model, "modelODEDoseInEquations" ),
      prop( model, "solverInputs" ),
      atol = odeSolverParameters$atol,
      rtol = odeSolverParameters$rtol
    ) |> as.data.frame()

    .odeExtractOutputAtSamplingTimes( evaluationModelTmp, samplingTimes, outputNames )
  }

  if ( usesCovariateOccasionStructure( model ) )
    evaluateModelWithCovariates( model, arm, evaluateCore )
  else
    evaluateCore( model, arm )
}

# ==============================================================================
#' definePKModel
#' @name definePKModel
#' @param pkModel     A \code{ModelODEDoseInEquations} object.
#' @param pfimproject A \code{PFIMProject} object.
#' @export
# ==============================================================================

method( definePKModel, list( ModelODEDoseInEquations, PFIMProject ) ) = function( pkModel, pfimproject ) {
  prop( pkModel, "modelEquations" )
}
