#' @description
#' The class \code{CategoricalCovariateWithIOV} represents a categorical
#' covariate that varies across occasions (inter-occasion variability design).
#'
#' Typical use: crossover treatment sequences (AB/BA), period effects, etc.
#'
#' Each element of \code{sequences} is a character vector of category labels,
#' one per occasion.  \code{sequencesProportions} gives the fraction of subjects
#' following each sequence and must sum to 1.
#'
#' @title CategoricalCovariateWithIOV
#' @param name                Character — covariate identifier.
#' @param categories          Character vector of category labels;
#'                            first element is the reference level.
#' @param sequences           Named list of character vectors (one per sequence
#'                            group); names are auto-generated as
#'                            \code{"sequence_1"}, \code{"sequence_2"}, …
#' @param sequencesProportions Numeric vector summing to 1.
#' @param effects             Named list of covariate effects per category.
#' @include Covariate.R
#' @export

CategoricalCovariateWithIOV = new_class( "CategoricalCovariateWithIOV",
  parent = Covariate,
  properties = list(
    categories           = class_character,
    sequences            = class_list,
    sequencesProportions = class_double
  ),
  constructor = function( name, categories, sequences, sequencesProportions,
                          effects = list() ) {
    if ( abs( sum( sequencesProportions ) - 1 ) > .Machine$double.eps^0.5 )
      stop( "CategoricalCovariateWithIOV: sequencesProportions must sum to exactly 1." )

    # FIX: 1:length(sequences) → seq_along(sequences)
    names( sequences ) = paste0( "sequence_", seq_along( sequences ) )

    new_object( CategoricalCovariateWithIOV,
                name                 = name,
                effects              = effects,
                categories           = categories,
                sequences            = sequences,
                sequencesProportions = sequencesProportions )
  }
)

# ==============================================================================
#' getCovariateEffects: compute the effect vector for each sequence × occasion.
#'
#' Returns a nested named list:
#' \code{sequence_k → occasion_j → effectVector}
#'
#' Delegates each (sequence, occasion) pair to \code{createEffectVector}.
#' The outer level is named by the existing \code{sequences} names
#' (set to "sequence_k" in the constructor); \code{imap} preserves them so
#' the outer \code{set_names} is not needed.
#'
#' @name getCovariateEffects
#' @param covariate    A \code{CategoricalCovariateWithIOV} object.
#' @param effectVector Named numeric vector of baseline parameter values.
#' @return Nested named list — sequences × occasions → effectVector.
#' @export
# ==============================================================================

method( getCovariateEffects, CategoricalCovariateWithIOV ) = function( covariate, effectVector ) {
  sequences = prop( covariate, "sequences" )
  nOcc      = length( pluck( sequences, 1L ) )
  occNames  = paste0( "occasion_", seq_len( nOcc ) )

  imap( sequences, function( seqVals, seqName )
    seq_len( nOcc ) |>
      map( ~ createEffectVector( covariate, seqVals[[ .x ]], effectVector ) ) |>
      set_names( occNames )
  )
}
