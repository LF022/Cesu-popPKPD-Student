# ==============================================================================
#' tablesForReport — PopulationFim
#' @name tablesForReport
#' @export
# ==============================================================================

method( tablesForReport, list( PopulationFim, PFIMProject ) ) = function( fim, evaluation ) {

  SEAndRSE        = prop( fim, "SEAndRSE"     )$SEAndRSE
  M               = prop( fim, "fisherMatrix" )
  fe              = as.matrix( prop( fim, "fixedEffects"   ) )
  ve              = prop( fim,              "varianceEffects" )
  cn1             = prop( fim, "condNumberFixedEffects"    )
  cn2             = prop( fim, "condNumberVarianceEffects" )
  parameters      = prop( evaluation, "modelParameters" )
  modelError      = prop( evaluation, "modelError"       )
  modelCovariates = prop( evaluation, "modelCovariates"  )
  greek           = .GREEK_LATEX   # defined in Fim.R

  has_IOV = any( map_dbl( parameters, ~ pluck( .x, "gamma", .default = 0 ) ) > 0 )
  has_cov = length( modelCovariates ) > 0L

  muL    = paste0( .muNames( parameters, greek[ "mu" ] ),    "}$" )
  betaL  = if ( has_cov )
    paste0( greek[ "beta" ],
            str_remove( .betaInternalNamesFromCovariates( modelCovariates ), "^beta_" ), "}$" )
  else character( 0L )
  omegaL = paste0( .omegaNames( parameters, greek[ "omega" ] ), "}$" )
  gammaL = if ( has_IOV ) paste0( .gammaNames( parameters, greek[ "gamma" ] ), "}$" )
  else character( 0L )
  sigmaL = modelError |>
    map( function( err ) {
      out  = prop( err, "output" )
      sig2 = "$\\sigma^2_{"          # hardcoded: avoids .GREEK_LATEX["sigma"] bug
      c(
        if ( prop( err, "sigmaInter" ) != 0 && !prop( err, "sigmaInterFixed" ) )
          paste0( sig2, "inter_", out, "}$" ),
        if ( prop( err, "sigmaSlope"  ) != 0 && !prop( err, "sigmaSlopeFixed"  ) )
          paste0( sig2, "slope_", out, "}$" )
      )
    }) |> unlist( use.names = FALSE )

  feNames = c( muL, betaL );  dimnames( fe ) = list( feNames, feNames )
  veNames = c( omegaL, gammaL, sigmaL );
  colnames( ve ) = veNames;  rownames( ve ) = veNames

  .kbl_s = function( df )
    kbl( df ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE,
                   position = "center", font_size = 13 )

  FIMCriteriaTable = data.frame( det   = det( M ),
                                 dcrit = Dcriterion( fim ),
                                 fe    = cn1, ve = cn2 ) |>
    kbl( col.names = c( "", "", "Fixed effects", "Variance effects" ),
         align = "c" ) |>
    add_header_above( c( "determinant" = 1, "d-criterion" = 1,
                         "Condition number" = 2 ) ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE,
                   position = "center", font_size = 13 )

  SEAndRSETable = data.frame(
    c( muL, betaL, omegaL, gammaL, sigmaL ), round( SEAndRSE, 3 )
  ) |>
    (\( df ) { row.names( df ) = NULL; df })() |>
    kbl( col.names = c( "Parameters", "Parameter values", "SE", "RSE (%)"),
         align = "c", row.names = FALSE ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE,
                   position = "center", font_size = 13 )

  list( fixedEffectsTable    = .kbl_s( fe ),
        varianceEffectsTable = .kbl_s( ve ),
        FIMCriteriaTable     = FIMCriteriaTable,
        SEAndRSETable        = SEAndRSETable )
}

# â”€â”€ Report rendering â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# .renderReport, .renderEvalReport, .reportTemplatePath are defined in Fim.R.

#' @name generateReportEvaluation
#' @export
method( generateReportEvaluation, PopulationFim ) =
  .renderEvalReport( "EvaluationPopulationFIM.Rmd" )

#' @name generateReportOptimization
#' @export
method( generateReportOptimization, list( PopulationFim, MultiplicativeAlgorithm ) ) =
  .renderReport( "OptimizationMultiplicativeAlgorithmPopulationFIM.Rmd" )

#' @name generateReportOptimization
#' @export
method( generateReportOptimization, list( PopulationFim, FedorovWynnAlgorithm ) ) =
  .renderReport( "OptimizationFedorovWynnAlgorithmPopulationFIM.Rmd" )

#' @name generateReportOptimization
#' @export
method( generateReportOptimization, list( PopulationFim, SimplexAlgorithm ) ) =
  .renderReport( "OptimizationSimplexAlgorithmPopulationFIM.Rmd" )

#' @name generateReportOptimization
#' @export
method( generateReportOptimization, list( PopulationFim, PSOAlgorithm ) ) =
  .renderReport( "OptimizationPSOAlgorithmPopulationFIM.Rmd" )

#' @name generateReportOptimization
#' @export
method( generateReportOptimization, list( PopulationFim, PGBOAlgorithm ) ) =
  .renderReport( "OptimizationPGBOAlgorithmPopulationFIM.Rmd" )
