# â”€â”€ FIM instance factory (used by evaluateArm / evaluateDesign) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# Loaded after PopulationFim, IndividualFim, and BayesianFim are all defined.

#' Fresh \code{Fim} instance of the same subclass as \code{fim} (empty slots).
#'
#' Each arm evaluation must use its own instance so \code{evaluateFim} does not
#' mutate a shared template passed across arms. S7 may reuse one flyweight for
#' repeated empty constructors; \code{unserialize(serialize())} breaks that
#' sharing, then \code{S7::set_props()} resets slots on a distinct object
#' (see \url{https://rconsortium.github.io/S7/reference/set_props.html}).
#'
#' @param fim A \code{PopulationFim}, \code{IndividualFim}, or \code{BayesianFim}.
#' @return New empty object of the same class.
#' @keywords internal
.duplicateFim = function( fim ) {
  cls = S7::S7_class( fim )@name
  if ( !cls %in% c( "PopulationFim", "IndividualFim", "BayesianFim" ) )
    stop(
      sprintf( "Cannot duplicate FIM object of class '%s'.", cls ),
      call. = FALSE
    )
  clone = unserialize( serialize( fim, NULL ) )
  S7::set_props(
    clone,
    fisherMatrix              = numeric( 0 ),
    fixedEffects              = numeric( 0 ),
    varianceEffects           = numeric( 0 ),
    SEAndRSE                  = list(),
    condNumberFixedEffects    = 0.0,
    condNumberVarianceEffects = 0.0,
    shrinkage                 = numeric( 0 )
  )
}
