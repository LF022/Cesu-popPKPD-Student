#' @title LogNormal
#' @description Log-normal distribution for positive PK/PD parameters (default in PFIM).
#' @inheritParams Distribution
#' @include Distribution.R
#' @export

LogNormal = new_class( "LogNormal", package = "PFIM", parent = Distribution )

# ==============================================================================
#' Adjust gradients for the log-normal parameterization (chain rule on mu).
#'
#' @name adjustGradient
#' @param distribution A \code{LogNormal} object.
#' @param gradient Gradient of the response w.r.t. theta on the natural scale.
#' @param thetaValue Parameter value theta.
#' @return Gradient w.r.t. mu on the log scale.
#' @export
# ==============================================================================

method( adjustGradient, LogNormal ) = function( distribution, gradient, thetaValue ) {
  return( gradient * thetaValue )
}
