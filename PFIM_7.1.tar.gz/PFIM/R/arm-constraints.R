# Arm constraint tables for optimization algorithms.
# @include Arm.R

# ==============================================================================
#' getArmConstraints: get the administration and sampling time constraints for the MultiplicativeAlgorithm.
#' @name getArmConstraints
#' @param arm An \code{Arm} object.
#' @param optimizationAlgorithm An \code{Optimization} object with the chosen algorithm.
#' @return A list with the administration and sampling time constraints for the MultiplicativeAlgorithm.
#' @export
# ==============================================================================

method( getArmConstraints, list( Arm, MultiplicativeAlgorithm ) ) = function( arm, optimizationAlgorithm ) {

  armName = prop( arm, "name" )
  armSize = prop( arm, "size" )

  admins = map( prop( arm, "administrationsConstraints" ), function( administrationConstraint ) {
    outcome = prop( administrationConstraint, "outcome" )
    doses = paste0( "(", paste( unlist( prop( administrationConstraint, "doses" ) ), collapse = ", " ), ")" )
    setNames( list( doses ), outcome )
  })

  admins = flatten( admins )

  armConstraints = map( prop( arm, "samplingTimesConstraints" ), function( samplingConstraint ) {
    outcome = prop( samplingConstraint, "outcome" )
    initialSamplings = paste0( "(", paste( prop( samplingConstraint, "initialSamplings" ), collapse = ", " ), ")" )
    fixedTimes = paste0( "(", paste( prop( samplingConstraint, "fixedTimes" ), collapse = ", " ), ")" )
    numberOfsamplingsOptimisable = as.character( prop( samplingConstraint, "numberOfsamplingsOptimisable" ) )

    doseConstraints = admins[[outcome]]
    if ( is.null( doseConstraints ) ) doseConstraints = '.'

    list( "Arms name" = armName,
          "Number of subjects" = armSize,
          "Outcome" = outcome,
          "Initial samplings" = initialSamplings,
          "Fixed times" = fixedTimes,
          "Number of samplings optimisable" = numberOfsamplingsOptimisable,
          "Dose constraints" = doseConstraints)
  })
  return( armConstraints )
}

# ==============================================================================
#' getArmConstraints: get the administration and sampling time constraints for the FedorovWynnAlgorithm.
#' @name getArmConstraints
#' @param arm An \code{Arm} object.
#' @param optimizationAlgorithm An \code{Optimization} object with the chosen algorithm.
#' @return A list with the administration and sampling time constraints for the FedorovWynnAlgorithm.
#' @export
# ==============================================================================

method( getArmConstraints, list( Arm, FedorovWynnAlgorithm ) ) = function( arm, optimizationAlgorithm ) {

  armName = prop( arm, "name" )
  armSize = prop( arm, "size" )

  admins = map( prop( arm, "administrationsConstraints" ), function( administrationConstraint ) {
    outcome = prop( administrationConstraint, "outcome" )
    doses = paste0( "(", paste( unlist( prop( administrationConstraint, "doses" ) ), collapse = ", " ), ")" )
    setNames( list( doses ), outcome )
  })

  admins = flatten( admins )

  armConstraints = map( prop( arm, "samplingTimesConstraints" ), function( samplingConstraint ) {
    outcome = prop( samplingConstraint, "outcome" )
    initialSamplings = paste0( "(", paste( prop( samplingConstraint, "initialSamplings" ), collapse = ", " ), ")" )
    fixedTimes = paste0( "(", paste( prop( samplingConstraint, "fixedTimes" ), collapse = ", " ), ")" )
    numberOfsamplingsOptimisable = as.character( prop( samplingConstraint, "numberOfsamplingsOptimisable" ) )

    doseConstraints = admins[[outcome]]
    if ( is.null( doseConstraints ) ) doseConstraints = '.'

    list( "Arms name" = armName,
          "Number of subjects" = armSize,
          "Outcome" = outcome,
          "Initial samplings" = initialSamplings,
          "Fixed times" = fixedTimes,
          "Number of samplings optimisable" = numberOfsamplingsOptimisable,
          "Dose constraints" = doseConstraints )
  })

  return( armConstraints )
}

# ==============================================================================
#' getArmConstraints: get the administration and sampling time constraints for the SimplexAlgorithm.
#' @name getArmConstraints
#' @param arm An \code{Arm} object.
#' @param optimizationAlgorithm An \code{Optimization} object with the chosen algorithm.
#' @return A list with the administration and sampling time constraints for the SimplexAlgorithm.
#' @export
# ==============================================================================

method( getArmConstraints, list( Arm, SimplexAlgorithm ) ) = function( arm, optimizationAlgorithm ) {
  .armConstraintsContinuous( arm )
}

# ==============================================================================
#' getArmConstraints: get the administration and sampling time constraints for the PSOAlgorithm.
#' @name getArmConstraints
#' @param arm An \code{Arm} object.
#' @param optimizationAlgorithm An \code{Optimization} object with the chosen algorithm.
#' @return A list with the administration and sampling time constraints for the PSOAlgorithm.
#' @export
# ==============================================================================

method( getArmConstraints, list( Arm, PSOAlgorithm ) ) = function( arm, optimizationAlgorithm ) {
  .armConstraintsContinuous( arm )
}

# ==============================================================================
#' getArmConstraints: get the administration and sampling time constraints for the PGBOAlgorithm.
#' @name getArmConstraints
#' @param arm An \code{Arm} object.
#' @param optimizationAlgorithm An \code{Optimization} object with the chosen algorithm.
#' @return A list with the administration and sampling time constraints for the PGBOAlgorithm.
#' @export
# ==============================================================================

method( getArmConstraints, list( Arm, PGBOAlgorithm ) ) = function( arm, optimizationAlgorithm ) {
  .armConstraintsContinuous( arm )
}
