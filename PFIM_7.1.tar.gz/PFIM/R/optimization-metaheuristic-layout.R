# Flat vector layout for continuous metaheuristics (PSO / PGBO / Simplex Rcpp kernels).
# @include Optimization.R

.buildFlatSamplingLayout = function( design ) {
  arms         = prop( design, "arms" )
  initial_flat = numeric()
  windows_list = list()
  sorting_groups = list()
  group_specs  = list()
  flat_dim     = 0L
  group_idx    = 0L

  for ( arm in arms ) {
    armName = prop( arm, "name" )
    for ( st in prop( arm, "samplingTimes" ) ) {
      outcome = prop( st, "outcome" )
      samps   = prop( st, "samplings" )
      n_samps = length( samps )
      group_idx = group_idx + 1L

      initial_flat = c( initial_flat, samps )

      constraint = pluck(
        keep( prop( arm, "samplingTimesConstraints" ), ~ prop( .x, "outcome" ) == outcome ),
        1L
      )
      win        = prop( constraint, "samplingsWindows" )
      win_matrix = do.call( rbind, lapply( win, unlist ) )
      for ( i in seq_len( n_samps ) ) windows_list = append( windows_list, list( win_matrix ) )

      sorting_groups = append(
        sorting_groups,
        list( seq( flat_dim + 1L, flat_dim + n_samps ) )
      )
      group_specs[[ group_idx ]] = list(
        arm        = arm,
        armName    = armName,
        outcome    = outcome,
        constraint = constraint
      )
      flat_dim = flat_dim + n_samps
    }
  }

  list(
    initial_flat   = initial_flat,
    windows_list   = windows_list,
    sorting_groups = sorting_groups,
    group_specs    = group_specs
  )
}

.sampleFlatFromConstraints = function( layout ) {
  flat = layout$initial_flat
  for ( gi in seq_along( layout$group_specs ) ) {
    spec = layout$group_specs[[ gi ]]
    idx  = layout$sorting_groups[[ gi ]]
    flat[ idx ] = sort( generateSamplingsFromSamplingConstraints( spec$constraint ) )
  }
  flat
}

.checkFlatValidGroup = function( layout, flat_pos, group_id ) {
  spec      = layout$group_specs[[ group_id ]]
  idx       = layout$sorting_groups[[ group_id ]]
  samplings = flat_pos[ idx ]
  all( unlist( checkSamplingTimeConstraintsForMetaheuristic(
    spec$constraint, spec$arm, samplings, spec$outcome
  ) ) )
}

.isFlatValid = function( layout, flat_pos ) {
  all( vapply(
    seq_along( layout$group_specs ),
    function( g ) .checkFlatValidGroup( layout, flat_pos, g ),
    logical( 1L )
  ) )
}

.metaheuristicFitnessPenalty = 1e7
