#' @title ModelODEBolus
#' @description ODE model with bolus doses via initial conditions.
#' @inheritParams ModelODE
#' @param modelODE     A function: the compiled ODE solver function.
#' @param doseEvent    A list: dose events for the ODE solver.
#' @param solverInputs A list: solver inputs.
#' @include ModelODE.R
#' @export

ModelODEBolus = new_class( "ModelODEBolus", package = "PFIM", parent = ModelODE,
                           properties = list(
                             modelODE     = new_property(class_function, default = NULL),
                             doseEvent    = new_property(class_list,     default = list()),
                             solverInputs = new_property(class_list,     default = list())
                           ))

# ==============================================================================
#' defineModelWrapper: build the ODE wrapper function for the bolus model.
#' @name defineModelWrapper
#' @param model      An object of class \code{ModelODEBolus}.
#' @param evaluation An object of class \code{Evaluation}.
#' @return The model with updated properties.
# ==============================================================================

method( defineModelWrapper, ModelODEBolus ) = function( model, evaluation ) {

  equations                  = prop( evaluation, "modelEquations" )
  variableNames              = str_remove( names( equations ), "Deriv_" )
  outcomesWithAdministration = .getOutcomesFromEvaluation( evaluation )
  parameterNames             = map_chr( prop( evaluation, "modelParameters" ), "name" )
  functionArguments          = unique( c( parameterNames, variableNames, "t" ) )
  functionArgumentsSymbols   = map( functionArguments, as.symbol )

  outputs = prop( evaluation, "outputs" )
  prop( model, "outputFormula" ) <- outputs
  prop( model, "outputNames" ) <- names( outputs )
  prop( model, "outcomesWithAdministration" ) <- outcomesWithAdministration
  prop( model, "wrapper" ) <- .buildODEWrapper( equations, functionArguments )
  prop( model, "functionArguments" ) <- functionArguments
  prop( model, "functionArgumentsSymbol" ) <- functionArgumentsSymbols

  return( model )
}

# ==============================================================================
#' evaluateInitialConditions: evaluate initial conditions for the bolus model.
#' @name evaluateInitialConditions
#' @param model     An object of class \code{ModelODEBolus}.
#' @param arm       An object of class \code{Arm}.
#' @param doseEvent A data frame of dose events (required for bolus models).
#' @return A named numeric vector of evaluated initial conditions.
#' @export
# ==============================================================================

method( evaluateInitialConditions, ModelODEBolus ) = function( model, arm, doseEvent ) {

  outcomesWithAdministration = prop( model, "outcomesWithAdministration" )

  # Match doses to outcomes by name — never assume doseEvent row order matches
  # the outcomesWithAdministration order (multi-outcome safety).
  dosesAtT0 = doseEvent[ doseEvent$time == 0, , drop = FALSE ]
  doses = set_names(
    as.list( dosesAtT0$value[ match( outcomesWithAdministration, dosesAtT0$var ) ] ),
    paste0( "dose_", outcomesWithAdministration )
  )

  mu  = .extractMu( prop( model, "modelParameters" ) )
  env = list2env( c( as.list( mu ), doses ), parent = environment() )

  map( prop( arm, "initialConditions" ), ~ {
    if ( is.numeric( .x ) ) .x else eval( parse( text = .x ), envir = env )
  }) |> unlist()
}

# ==============================================================================
# Internal administration builders (shared with gradient performance cache).
# ==============================================================================

#' @keywords internal
.odeBolusDoseEventTemplate = function( arm, samplings ) {
  administrations = prop( arm, "administrations" )
  map( administrations, function( adm ) {
    outcome  = prop( adm, "outcome" )
    tau      = prop( adm, "tau" )
    dosing   = .alignAdministrationDosing( adm )
    timeDose = dosing$timeDose
    dose     = dosing$dose

    if ( tau != 0 ) {
      timeDose = seq( 0, max( samplings ), tau )
      dose     = rep( dose, length( timeDose ) )
    }
    data.frame(
      var    = rep( outcome, length( timeDose ) ),
      time   = timeDose,
      value  = dose,
      method = ifelse( timeDose == 0, "replace", "add" )
    )
  } ) |> list_rbind() |> ( function( df ) df[ order( df$time ), ] )()
}

#' @keywords internal
.odeBolusFinalizeAdministration = function(
    model, mu, doseEvent, initialConditions, samplings,
    wrapper, functionArguments, functionArgumentsSymbols, outputFormula ) {

  modelODEBolus = function( t, y, parms ) {
    with( as.list( c( t = t, y, mu ) ), {
      evaluationModel   = do.call( wrapper, set_names( functionArgumentsSymbols, functionArguments ) )
      evaluationOutputs = map( outputFormula, ~ eval( .x ) )
      return( c( evaluationModel, evaluationOutputs ) )
    } )
  }

  prop( model, "initialConditions" ) <- initialConditions
  prop( model, "samplings" ) <- samplings
  prop( model, "modelODE" ) <- modelODEBolus
  prop( model, "doseEvent" ) <- doseEvent
  model
}

#' @keywords internal
.odeExtractOutputAtSamplingTimes = function( evaluationModelTmp, samplingTimes, outputNames ) {
  samplings_list = set_names(
    map( samplingTimes, ~ prop( .x, "samplings" ) ),
    outputNames
  )

  set_names(
    map( outputNames, function( out_name ) {
      req_times = samplings_list[[ out_name ]]
      idx = vapply( req_times, function( rt ) {
        which.min( abs( evaluationModelTmp$time - rt ) )
      }, integer( 1L ), USE.NAMES = FALSE )

      df = data.frame( time = req_times, val = evaluationModelTmp[ idx, out_name ] )
      names( df )[ 2L ] = out_name
      df
    } ),
    outputNames
  )
}

# ==============================================================================
#' defineModelAdministration: build the dose event table and ODE function.
#' @name defineModelAdministration
#' @param model An object of class \code{ModelODEBolus}.
#' @param arm   An object of class \code{Arm}.
#' @return The model with updated properties.
#' @export
# ==============================================================================

method( defineModelAdministration, ModelODEBolus ) = function( model, arm ) {

  samplingTimes            = prop( arm,   "samplingTimes" )
  samplings                = .buildSamplings( samplingTimes )
  wrapper                  = prop( model, "wrapper" )
  parameters               = prop( model, "modelParameters" )
  functionArguments        = prop( model, "functionArguments" )
  functionArgumentsSymbols = prop( model, "functionArgumentsSymbol" )
  outputFormula            = map( prop( model, "outputFormula" ), ~ parse( text = .x ) )
  mu                       = .extractMu( parameters )

  doseEvent = .odeBolusDoseEventTemplate( arm, samplings )
  initialConditions = evaluateInitialConditions( model, arm, doseEvent )

  initialConditionsTmp = prop( arm, "initialConditions" )
  env = list2env( as.list( mu ), parent = environment() )
  walk( seq_len( nrow( doseEvent ) ), function( iter ) {
    outcomeName = doseEvent$var[ iter ]
    assign( paste0( "dose_", outcomeName ), doseEvent$value[ iter ], envir = env )
    doseEvent$value[ iter ] <<- eval(
      parse( text = initialConditionsTmp[[ outcomeName ]] ), envir = env
    )
  } )

  .odeBolusFinalizeAdministration(
    model, mu, doseEvent, initialConditions, samplings,
    wrapper, functionArguments, functionArgumentsSymbols, outputFormula
  )
}

# ==============================================================================
#' evaluateModel: solve the bolus ODE model.
#' @name evaluateModel
#' @param model An object of class \code{ModelODEBolus}.
#' @param arm   An object of class \code{Arm}.
#' @return A named list of data frames, one per output.
#' @export
# ==============================================================================

method( evaluateModel, ModelODEBolus ) = function( model, arm ) {

  evaluateCore = function( model, arm ) {
    odeSolverParameters = prop( model, "odeSolverParameters" )
    outputNames         = prop( model, "outputNames" )
    samplingTimes       = prop( arm,   "samplingTimes" )

    raw_samplings = prop( model, "samplings" )
    events_df     = prop( model, "doseEvent" )
    sim_key       = paste(
      "bolus", paste( raw_samplings, collapse = "," ),
      paste( events_df$time, events_df$value, sep = ":", collapse = "," ),
      sep = "::"
    )
    sim_times = .pfimOdeSimTimesCached( sim_key, raw_samplings, events_df )

    evaluationModelTmp = ode(
      prop( model, "initialConditions" ),
      sim_times,
      prop( model, "modelODE" ),
      NULL,
      events = list( data = events_df ),
      atol   = odeSolverParameters$atol,
      rtol   = odeSolverParameters$rtol
    ) |> as.data.frame()

    .odeExtractOutputAtSamplingTimes( evaluationModelTmp, samplingTimes, outputNames )
  }

  if ( usesCovariateOccasionStructure( model ) )
    evaluateModelWithCovariates( model, arm, evaluateCore )
  else
    evaluateCore( model, arm )
}

# ==============================================================================
#' definePKModel: define the PK model for bolus ODE.
#' @name definePKModel
#' @param pkModel     An object of class \code{ModelODEBolus}.
#' @param pfimproject An object of class \code{PFIMProject}.
#' @export
# ==============================================================================

method( definePKModel, list( ModelODEBolus, PFIMProject ) ) = function( pkModel, pfimproject ) {

  variablesNames = prop( pfimproject, "designs" ) |>
    map( \(d) map( prop( d, "arms" ), \(arm) prop( arm, "initialConditions" ) ) ) |>
    unlist() |> names() |> unique()

  prop( pkModel, "modelEquations" ) |>
    imap( ~ reduce2( c("C1","C2"), variablesNames, replaceVariablesLibraryOfModels, .init = .x ) ) |>
    set_names( paste0( "Deriv_", variablesNames ) )
}
