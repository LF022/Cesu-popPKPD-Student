# HTML optimization report assembly.
# @include Optimization.R
# @include Evaluation.R

# ==============================================================================
#' Report: generate the HTML optimization report
#' @name Report
#' @param pfimproject  An \code{Optimization} object.
#' @param outputPath   Directory for the rendered HTML file.
#' @param outputFile   File name for the rendered HTML file.
#' @param plotOptions  Plot options passed to plotEvaluation.
#' @export
# ==============================================================================

method( Report, Optimization ) = function( pfimproject, outputPath, outputFile, plotOptions ) {

  projectName = projectProp( pfimproject, "name" )

  optimisationDesign      = prop( pfimproject, "optimisationDesign" )
  evaluationInitialDesign = optimisationDesign$evaluationInitialDesign
  evaluationOptimalDesign = optimisationDesign$evaluationOptimalDesign
  evaluationOutputs       = projectProp( pfimproject, "outputs" )

  model          = rebuildEvalModel( evaluationInitialDesign, finiteDifference = FALSE )
  modelEquations = prop( model, "modelEquations" )

  modelErrorData = prop( evaluationInitialDesign, "modelError" ) |>
    map( getModelErrorData ) |>
    map( ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |>
    list_rbind()
  colnames( modelErrorData ) = c( "Output", "Type", "$\\sigma_{slope}$", "$\\sigma_{inter}$" )
  modelErrorTable = kbl( modelErrorData, align = "c" ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE,
                   position = "center", font_size = 13 )

  modelParametersTable = .buildModelParametersKable( prop( evaluationInitialDesign, "modelParameters" ) )

  modelCovariates = prop( evaluationInitialDesign, "modelCovariates" )
  hasCov          = length( modelCovariates ) > 0L

  covariatesTable     = .buildCovariatesKable( modelCovariates )
  covariateTestTables = if ( hasCov ) .buildCovariateTestSection( evaluationOptimalDesign ) else NULL

  .buildArmTable = function( evaluation, colnamesVec ) {
    designs  = prop( evaluation, "designs" )
    armsData = list_flatten( map( pluck( map( designs, ~ prop( .x, "arms" ) ), 1L ),
                                  getArmData ) )
    df = map( armsData, ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |> list_rbind()
    colnames( df ) = colnamesVec
    df
  }

  administrationData = prop( evaluationInitialDesign, "designs" ) |>
    map( ~ prop( .x, "arms" ) ) |>
    pluck( 1L ) |>
    map( armAdministration ) |>
    list_flatten() |>
    map( ~ as.data.frame( .x, stringsAsFactors = FALSE ) ) |>
    list_rbind()
  colnames( administrationData ) = c( "Design name", "Arms name", "Number of subject",
                                      "Outcome", "Dose", "Time dose",
                                      "$\\tau$", "$T_{inf}$" )
  administrationTable = kbl( administrationData, align = c( "l","l","l","c","c","c","c" ) ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE,
                   position = "center", font_size = 13 )

  armCols           = c( "Arms name", "Number of subjects", "Outcome", "Dose", "Sampling times" )
  initialDesignData = .buildArmTable( evaluationInitialDesign, armCols )
  initialDesignTable = kbl( initialDesignData, align = c( "l","c","c","c" ) ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE,
                   position = "center", font_size = 13 )

  fimInitial            = setEvaluationFim( prop( evaluationInitialDesign, "fim" ), evaluationInitialDesign )
  fimInitialDesignTable = tablesForReport( fimInitial, evaluationInitialDesign )

  optimAlgoOutputs      = prop( pfimproject, "optimisationAlgorithmOutputs" )
  optimizationAlgorithm = optimAlgoOutputs$optimizationAlgorithm
  constraintsData       = constraintsTableForReport(
    optimizationAlgorithm,
    map( prop( evaluationInitialDesign, "designs" ), ~ prop( .x, "arms" ) )
  )

  optimalDesignData  = .buildArmTable( evaluationOptimalDesign, armCols )
  optimalDesignTable = kbl( optimalDesignData, align = c( "l","c","c","c","c" ) ) |>
    kable_styling( bootstrap_options = "hover", full_width = FALSE,
                   position = "center", font_size = 13 )

  fimOptimal      = setEvaluationFim( prop( evaluationOptimalDesign, "fim" ), evaluationOptimalDesign )
  fimOptimalTable = tablesForReport( fimOptimal, evaluationOptimalDesign )

  plotsEvaluationData        = plotEvaluation(          evaluationOptimalDesign, plotOptions )
  plotSensitivityIndicesData = plotSensitivityIndices(  evaluationOptimalDesign, plotOptions )
  plotSEData                 = plotSEFIM(  fimOptimal,  evaluationOptimalDesign )
  plotRSEData                = plotRSEFIM( fimOptimal,  evaluationOptimalDesign )

  reportTables = list(
    evaluationOutputs         = evaluationOutputs,
    modelEquations            = modelEquations,
    modelErrorTable           = modelErrorTable,
    modelParametersTable      = modelParametersTable,
    covariatesTable           = covariatesTable,
    covariateTestTables       = covariateTestTables,
    administrationTable       = administrationTable,
    initialDesignTable        = initialDesignTable,
    constraintsTableForReport = constraintsData,
    armsConstraintsTable      = constraintsData,
    fimInitialDesignTable     = fimInitialDesignTable,
    optimalDesignTable        = optimalDesignTable,
    fimOptimalTable           = fimOptimalTable,
    plotsEvaluation           = plotsEvaluationData,
    plotSensitivityIndices    = plotSensitivityIndicesData,
    plotSE                    = plotSEData,
    plotRSE                   = plotRSEData,
    fim                       = fimOptimal,
    pfimproject               = pfimproject,
    projectName               = projectName
  )

  generateReportOptimization( fimOptimal, optimizationAlgorithm,
                              reportTables, outputFile, outputPath )
}
