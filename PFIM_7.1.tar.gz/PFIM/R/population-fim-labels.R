# â”€â”€ Private name-extraction helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

.muNames = function( parameters, greek )
  parameters |>
  keep( ~ !isTRUE( prop( .x, "fixedMu" ) ) &&
          prop( prop( .x, "distribution" ), "mu" ) != 0 ) |>
  map_chr( ~ paste0( greek, prop( .x, "name" ) ) )

.omegaNames = function( parameters, greek )
  parameters |>
  keep( ~ !isTRUE( prop( .x, "fixedOmega" ) ) &&
          prop( prop( .x, "distribution" ), "omega" ) != 0 ) |>
  map_chr( ~ paste0( greek, prop( .x, "name" ) ) )

.gammaNames = function( parameters, greek )
  parameters |>
  keep( ~ pluck( .x, "gamma", .default = 0 ) > 0 &&
          !isTRUE( prop( .x, "fixedOmega" ) ) ) |>
  map_chr( ~ paste0( greek, prop( .x, "name" ) ) )

.sigmaNames = function( modelError, greekSigma, sep = "_" )
  modelError |>
  map( function( err ) {
    out = prop( err, "output" )
    c(
      if ( prop( err, "sigmaInter" ) != 0 && !prop( err, "sigmaInterFixed" ) )
        paste0( greekSigma, sep, "inter_", out ),
      if ( prop( err, "sigmaSlope"  ) != 0 && !prop( err, "sigmaSlopeFixed"  ) )
        paste0( greekSigma, sep, "slope_", out )
    )
  }) |> unlist( use.names = FALSE )

