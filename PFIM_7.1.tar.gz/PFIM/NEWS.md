# PFIM 8.0

## PFIM 8.0 (2026-06-06)

### Release

- CRAN release 8.0 (`DESCRIPTION`, `NEWS.md`, `README.md` aligned)
- Copyright: Inserm, Romain Leroux (2020-2026)

### CRAN polish

- Removed non-standard `objdump` logic from `src/Makevars.win`
- Simplex C++: convergence message only when `showProcess = TRUE` (cleaner test output)
- Removed redundant `importFrom(S7, prop)` from `NAMESPACE` (`import(S7)` suffices)

## PFIM 7.1 (2026-06-04)

### Architecture

- S7 object system for `Evaluation`, `Optimization`, `Model`, `Fim`, and related classes
- Split `Model.R` into `model-covariates.R` and `model-evaluation.R`
- Split `Optimization.R` into `optimization-metaheuristic-layout.R`, `optimization-constraints.R`, `optimization-report.R`
- Split `Arm.R` into `arm-administration.R`, `arm-constraints.R`, `arm-plots.R`

### Performance

- Parallel FIM evaluation via `future` / `furrr` (`configureParallel()`, `parallelStatus()`)
- Optional parallel finite-difference gradients (`options(PFIM.parallel.gradients = TRUE)`)
- ODE gradient performance caches: administration reuse, FD scheme cache, deSolve time grid (`PFIM.perf.*`, default on)
- FIM design cache during constraint enumeration (`options(PFIM.fim.cache = TRUE)`)
- Batch model rebuild during constraint grid evaluation
- C++ optimizer hot paths: pre-converted Armadillo structures (Multiplicative, Simplex, PSO, PGBO)

### Optimization

- Fedorov-Wynn final evaluations parallelized via `.pfimRunEvaluations()`
- All discrete optimizers use parallel `generateFimsFromConstraints()` when enabled
- Fixed Fedorov-Wynn R/C++ buffer sizing: `fisher` and population vectors now match FIM dimension (`ndimFim`), not only the number of candidate protocols

### Documentation

- New vignettes: `Example03_GCSF`, `Example04_Fakinumab` (PopED-aligned tutorials)
- New vignette: `ParallelFIM` (includes Windows parallel setup)
- Updated vignette: `FIM-types-and-covariateTest`
- Package URL points to GitHub (CRAN incoming check)
- `README.md` and `NEWS.md` at package root

### CRAN

- Removed invalid `pfim.biostat.fr` URL
- `RcppArmadillo` moved to `LinkingTo` only
- Fixed non-ASCII characters, `parallelly` declaration, and `.GlobalEnv` assignments in parallel code
- `codecov.yml` excluded from the source tarball (CI config only)

### Testing

- 215+ passing `testthat` tests including gradient performance regression, parallel (Linux/macOS CI), FIM cache, and optimizer smoke tests
- End-to-end tests for all five optimizers (Multiplicative, Fedorov-Wynn, PSO, PGBO, Simplex)
- Fedorov-Wynn C++ integration tests (buffer sizing, no subscript warnings)
- Parallel optimizer tests run on all platforms including Windows (`future::multisession`)
- Parallel workers prefer `PFIM.devPath` when set; relayed package-version warnings from workers are muffled
- GitHub Actions at repository root: multi-OS `R CMD check` and integration tests
