# FIM design cache (Phase 2).

test_that("FIM design cache returns same result without re-running", {
  old = options(
    PFIM.parallel       = FALSE,
    PFIM.fim.cache      = TRUE,
    PFIM.fim.cache.hits = 0L
  )
  on.exit( do.call( options, old ), add = TRUE )

  opt = .minimal_mult_opt()
  PFIM:::.pfimFimCacheBegin( opt )
  ev  = PFIM:::.evaluationFromProject( opt )

  r1 = PFIM:::.pfimRunEvaluationCached( ev )
  r2 = PFIM:::.pfimRunEvaluationCached( ev )

  expect_equal( getDeterminant( r1 ), getDeterminant( r2 ) )
  expect_gte( getOption( "PFIM.fim.cache.hits" ), 1L )
} )

test_that("optimization reuses FIM cache for final design evaluations", {
  old = options( PFIM.parallel = FALSE, PFIM.fim.cache = TRUE )
  on.exit( do.call( options, old ), add = TRUE )

  opt = .minimal_mult_opt()
  opt = run( opt )

  stats = PFIM:::.pfimFimCacheStats()
  expect_gte( stats$hits, 1L )
  expect_gt( stats$size, 0L )
} )

test_that("constraint grid uses batch model rebuild", {
  old = options( PFIM.parallel = FALSE, PFIM.fim.cache = TRUE )
  on.exit( do.call( options, old ), add = TRUE )

  opt = .minimal_mult_opt()
  invisible( generateFimsFromConstraints( opt ) )

  expect_true( isTRUE( getOption( "PFIM.eval.batch", FALSE ) ) ||
    !is.null( getOption( "PFIM.fim.cache.scope" ) ) )
  stats = PFIM:::.pfimFimCacheStats()
  expect_gt( stats$size, 0L )
  expect_false( is.null( getOption( "PFIM.fim.cache.scope" ) ) )
} )

test_that("PFIM.fim.cache = FALSE bypasses cache", {
  old = options(
    PFIM.parallel       = FALSE,
    PFIM.fim.cache      = FALSE,
    PFIM.fim.cache.hits = 0L
  )
  on.exit( do.call( options, old ), add = TRUE )

  opt = .minimal_mult_opt()
  PFIM:::.pfimFimCacheBegin( opt )
  ev = PFIM:::.evaluationFromProject( opt )

  PFIM:::.pfimRunEvaluationCached( ev )
  PFIM:::.pfimRunEvaluationCached( ev )

  expect_equal( getOption( "PFIM.fim.cache.hits" ), 0L )
} )
