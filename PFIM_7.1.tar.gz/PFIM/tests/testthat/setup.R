# Isolate unit tests from interactive PFIM.parallel / PFIM.workers options.
options(
  PFIM.parallel = FALSE,
  PFIM.workers  = 1L
)
