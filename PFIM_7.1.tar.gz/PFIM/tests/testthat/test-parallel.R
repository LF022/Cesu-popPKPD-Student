# Parallel configuration API (requires future/furrr for full validation).

test_that("configureParallel and parallelStatus are available", {
  expect_true( exists( "configureParallel", mode = "function" ) )
  expect_true( exists( "parallelStatus", mode = "function" ) )
  st = parallelStatus()
  expect_type( st, "list" )
  expect_true( "parallel_enabled" %in% names( st ) )
})

test_that("configureParallel( parallel = FALSE ) disables parallel", {
  old = getOption( "PFIM.parallel" )
  on.exit( options( PFIM.parallel = old ), add = TRUE )
  configureParallel( parallel = FALSE, validate = FALSE, quiet = TRUE )
  expect_false( isTRUE( getOption( "PFIM.parallel" ) ) )
})

test_that("parallel map falls back when parallel is off", {
  old = getOption( "PFIM.parallel" )
  on.exit( options( PFIM.parallel = old ), add = TRUE )
  options( PFIM.parallel = FALSE )
  out = PFIM:::.pfimParallelMap( 1:3, identity )
  expect_equal( out, as.list( 1:3 ) )
})

test_that("nested parallel is disabled inside workers", {
  expect_false( PFIM:::.pfimUseParallel( 10L ) )
  options( PFIM.inWorker = TRUE )
  on.exit( options( PFIM.inWorker = NULL ), add = TRUE )
  expect_false( PFIM:::.pfimUseParallel( 10L ) )
})
