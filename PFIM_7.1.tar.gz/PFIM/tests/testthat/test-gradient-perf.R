test_that("gradient performance options preserve FIM results (ODE 1cpt)", {
  admin = Administration( outcome = "RespPK", timeDose = 0, dose = 100 )
  st    = SamplingTimes( outcome = "RespPK", samplings = c( 0.5, 2, 4, 6 ) )
  arm   = Arm(
    name = "arm", size = 40,
    administrations = list( admin ),
    samplingTimes   = list( st )
  )
  design = Design( name = "d", arms = list( arm ) )
  mp = list(
    ModelParameter( name = "ka", distribution = LogNormal( mu = 1, omega = 0.3 ) ),
    ModelParameter( name = "V",  distribution = LogNormal( mu = 3.5, omega = 0.3 ) ),
    ModelParameter( name = "Cl", distribution = LogNormal( mu = 2, omega = 0.3 ) )
  )
  err = Constant( output = "RespPK", sigmaInter = 0.1 )
  ev = Evaluation(
    name = "perf_test",
    modelFromLibrary = list( PKModel = "Linear1FirstOrderSingleDose_kaClV" ),
    modelParameters  = mp,
    modelError       = list( err ),
    outputs          = list( "RespPK" ),
    designs          = list( design ),
    fimType          = "population",
    odeSolverParameters = list( atol = 1e-8, rtol = 1e-8 )
  )

  opts_off = list(
    PFIM.perf.adminCache     = FALSE,
    PFIM.perf.fdCache        = FALSE,
    PFIM.perf.odeTimesCache  = FALSE,
    PFIM.parallel.gradients  = FALSE,
    PFIM.parallel            = FALSE
  )
  opts_on = list(
    PFIM.perf.adminCache     = TRUE,
    PFIM.perf.fdCache        = TRUE,
    PFIM.perf.odeTimesCache  = TRUE,
    PFIM.parallel.gradients  = FALSE,
    PFIM.parallel            = FALSE
  )

  run_baseline = function( opts ) {
    old = options( opts )
    on.exit( do.call( options, old ), add = TRUE )
    out = run( ev )
    list(
      det = getDeterminant( out ),
      rse = getRSE( out )$RSE
    )
  }

  base = run_baseline( opts_off )
  fast = run_baseline( opts_on )

  expect_equal( fast$det, base$det, tolerance = 1e-6 )
  expect_equal( fast$rse, base$rse, tolerance = 1e-6 )
})

test_that("parallel gradients match sequential when future/furrr available", {
  skip_if_not( requireNamespace( "future", quietly = TRUE ) &&
                 requireNamespace( "furrr", quietly = TRUE ) )

  admin = Administration( outcome = "RespPK", timeDose = 0, dose = 100 )
  st    = SamplingTimes( outcome = "RespPK", samplings = c( 1, 2, 3 ) )
  arm   = Arm(
    name = "arm", size = 30,
    administrations = list( admin ),
    samplingTimes   = list( st )
  )
  design = Design( name = "d", arms = list( arm ) )
  mp = list(
    ModelParameter( name = "k", distribution = LogNormal( mu = 0.25, omega = 0.5 ) ),
    ModelParameter( name = "V", distribution = LogNormal( mu = 15, omega = 0.3 ) )
  )
  err = Combined1( output = "RespPK", sigmaInter = 0.5, sigmaSlope = 0.15 )
  ev = Evaluation(
    name = "grad_par",
    modelFromLibrary = list( PKModel = "Linear1BolusSingleDose_kV" ),
    modelParameters  = mp,
    modelError       = list( err ),
    outputs          = list( "RespPK" ),
    designs          = list( design ),
    fimType          = "individual",
    odeSolverParameters = list( atol = 1e-8, rtol = 1e-8 )
  )

  run_with = function( grad_par ) {
    old = options(
      PFIM.parallel = FALSE,
      PFIM.parallel.gradients = grad_par,
      PFIM.perf.adminCache = TRUE,
      PFIM.perf.fdCache = TRUE,
      PFIM.perf.odeTimesCache = TRUE
    )
    on.exit( do.call( options, old ), add = TRUE )
    if ( grad_par )
      configureParallel( parallel = FALSE, parallel.gradients = TRUE, validate = FALSE, quiet = TRUE )
    out = run( ev )
    getDeterminant( out )
  }

  d_seq = run_with( FALSE )
  d_par = run_with( TRUE )
  expect_equal( d_par, d_seq, tolerance = 1e-8 )
})
