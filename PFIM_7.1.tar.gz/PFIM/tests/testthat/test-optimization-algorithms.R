# End-to-end optimization smoke tests for all algorithms.

test_that("FedorovWynnAlgorithm: run() completes with valid optimal design", {
  opt = .minimal_discrete_opt( "FedorovWynnAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("PSOAlgorithm: run() completes with valid optimal design", {
  opt = .minimal_continuous_opt( "PSOAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("PGBOAlgorithm: run() completes with valid optimal design", {
  opt = .minimal_continuous_opt( "PGBOAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("SimplexAlgorithm: run() completes with valid optimal design", {
  opt = .minimal_continuous_opt( "SimplexAlgorithm" )
  .expect_optimization_run( opt )
})

test_that("FedorovWynnAlgorithm with parallel: run() completes when future/furrr available", {
  skip_if_not_installed( "future" )
  skip_if_not_installed( "furrr" )
  opt = .with_parallel_if_available(
    .expect_optimization_run( .minimal_discrete_opt( "FedorovWynnAlgorithm", name = "fw_par" ) )
  )
  expect_s7_class( opt, Optimization )
})

test_that("PSOAlgorithm with parallel: run() completes when future/furrr available", {
  skip_if_not_installed( "future" )
  skip_if_not_installed( "furrr" )
  opt = .with_parallel_if_available(
    .expect_optimization_run( .minimal_continuous_opt( "PSOAlgorithm", name = "pso_par" ) )
  )
  expect_s7_class( opt, Optimization )
})

test_that("PGBOAlgorithm with parallel: run() completes when future/furrr available", {
  skip_if_not_installed( "future" )
  skip_if_not_installed( "furrr" )
  opt = .with_parallel_if_available(
    .expect_optimization_run( .minimal_continuous_opt( "PGBOAlgorithm", name = "pgbo_par" ) )
  )
  expect_s7_class( opt, Optimization )
})

test_that("SimplexAlgorithm with parallel: run() completes when future/furrr available", {
  skip_if_not_installed( "future" )
  skip_if_not_installed( "furrr" )
  opt = .with_parallel_if_available(
    .expect_optimization_run( .minimal_continuous_opt( "SimplexAlgorithm", name = "simplex_par" ) )
  )
  expect_s7_class( opt, Optimization )
})

test_that("MultiplicativeAlgorithm with parallel: run() completes when future/furrr available", {
  skip_if_not_installed( "future" )
  skip_if_not_installed( "furrr" )
  opt = .with_parallel_if_available(
    .expect_optimization_run( .minimal_discrete_opt( "MultiplicativeAlgorithm", name = "mult_par" ) )
  )
  expect_s7_class( opt, Optimization )
})

test_that("generateFimsFromConstraints uses parallel map when enabled", {
  skip_if_not_installed( "future" )
  skip_if_not_installed( "furrr" )
  opt = .minimal_discrete_opt( "MultiplicativeAlgorithm" )
  old = getOption( "PFIM.parallel" )
  on.exit( options( PFIM.parallel = old ), add = TRUE )
  configureParallel( workers = 2, validate = FALSE, quiet = TRUE )
  res = generateFimsFromConstraints( opt )
  expect_type( res, "list" )
  expect_true( length( res$listFimsAlgoMult ) >= 1L )
  expect_gte( nrow( res$listFimsAlgoMult[[ 1L ]][[ 1L ]] ), 1L )
})
